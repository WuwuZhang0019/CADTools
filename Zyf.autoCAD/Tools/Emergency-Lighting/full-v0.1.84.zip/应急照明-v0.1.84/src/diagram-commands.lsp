;; Date: 2026-10-15. Common publication/synchronization entry points.
(defun EL:PowerInputPath (panel / drawing)
  (if (and panel *EL:Root* (setq drawing (EL:DrawingID)))
    (strcat *EL:Root* "config/power-input-" (EL:Hash (strcat drawing "/" panel)) ".eld")))
(defun EL:RememberPanelPowers (result powers / path)
  (if (assoc 'device-library result) (EL:DLRememberInputs result powers)
  (if (setq path (EL:PowerInputPath (EL:Get 'panel result)))
    (EL:WriteData path (list '(version . 1) (cons 'powers
      (vl-remove-if-not '(lambda (row) (numberp (cdr row))) powers)))))))
(defun EL:FixedPowers (record / data powers row path remembered)
  ;; Date: 2026-10-11. Shared defaults come only from ELDEVLIB; DWG values remain local.
  (setq powers (EL:Get 'powers record))
  (if (and (setq path (EL:PowerInputPath (EL:Get 'source-panel-handle record)))
      (setq remembered (EL:ReadData path)) (EL:SimplePowersValid remembered))
    (foreach row (EL:Get 'powers remembered) (setq powers (EL:Put (car row) (cdr row) powers))))
  (if (setq remembered (EL:DLLoadInputs (EL:Get 'source-panel-handle record)))
    (foreach row (EL:Get 'device-overrides remembered)
      (if (EL:Get 'watts-set (cdr row)) (setq powers (EL:Put (car row) (EL:Get 'watts (cdr row)) powers)))))
  powers)
(defun EL:SaveNamePowers (powers / data row merged)
  (if (setq data (EL:SimpleLoadPowers))
    (progn
      (setq merged (EL:Get 'powers data))
      (foreach row powers
        (if (numberp (cdr row)) (setq merged (EL:Put (car row) (cdr row) merged))))
      (EL:WriteData (strcat *EL:Root* "config/block-powers.eld") (list '(version . 1) (cons 'powers merged))))))
(defun EL:SaveDraft (result cfg powers capacity)
  ;; Date: 2026-10-21. Include input preparation and verified transaction readback.
  (EL:PerfCall "SAVE_GENERATION_DRAFT" 'EL:SaveDraftWork (list result cfg powers capacity)))
(defun EL:SaveDraftWork (result cfg powers capacity / store record context)
  (setq *EL:LastSavedDraftId* nil)
  (if (assoc 'effective-powers result) (setq powers (EL:Get 'effective-powers result)))
  (setq capacity (EL:CapacityDefault capacity))
  (if (not (EL:Get 'capacity-source result)) (setq result (EL:Put 'capacity-source 'default result)))
  (setq store (cond ((EL:StoreForResult result)) (T (EL:StoreInitial)))
    record (cond ((EL:RecordForResult result store)) (T (EL:NewRecord (EL:Get 'panel result) store))))
  ;; Date: 2026-10-14. Saving inputs must not revise an earlier output's
  ;; record. A new draft becomes the latest entry for the source box.
  (if (EL:Get 'panel-output-handle record)
    ;; A new input record has no formal output of its own.
    (setq record (EL:NewRecord (EL:Get 'panel result) store)))
  ;; Date: 2026-10-15. Fresh inputs and their config use the same current template.
  ;; Historical records for other panels retain their own verified templates.
  (setq record (EL:Put 'template (EL:Get 'template cfg) record))
  (setq
    record (EL:Put 'draft-circuits (EL:Get 'circuits result) (EL:Put 'draft-capacity capacity
      (EL:Put 'powers powers (EL:Put 'config cfg (EL:Put 'engine (EL:Get 'engine result) record))))))
  (setq record (EL:Put 'panel-number (EL:PanelNumber result) record))
  (setq record (EL:RecordNumberInputs record result T))
  (setq record (EL:DLPersist result record))
  ;; Date: 2026-10-14. Preserve legacy ground choices, but no hidden
  ;; device/exit exclusions in the new directed-pick flow.
  (if (assoc 'block-ground result)
    (setq record (EL:Put 'block-ground (EL:Get 'block-ground result) record)))
  (setq record (EL:Put 'candidate-keys (EL:Get 'candidate-keys result)
    (EL:Put 'draft-capacity-source (EL:Get 'capacity-source result) record)))
  (if (not (EL:Get 'panel-output-handle record))
    (setq record (EL:RecordNumberInputs (EL:Put 'rows (EL:Get 'circuits result)
      (EL:Put 'capacity-source (EL:Get 'capacity-source result) (EL:Put 'capacity-option capacity record))) result nil)))
  (if (or (not (EL:Get 'can-generate result)) (not (EL:CircuitNumbersReady result)) (not (EL:SelectionsReady result capacity)))
    (setq record (EL:Put 'status 'stale record)))
  ;; Date: 2026-10-14. A saved draft has not yet generated its own diagram.
  (if (EL:Get 'panel-output-handle record)
    (setq record (EL:Put 'stale-reason 'draft-saved (EL:Put 'status 'stale record))))
  (if (EL:TemplateReady (EL:Get 'template cfg) cfg)
    (setq store (EL:Put 'fixed-template (EL:Get 'template cfg) store)))
  (EL:Require (or (and (not (EL:Get 'can-generate result))
      (EL:Get 'load-error (EL:Get 'device-library result)))
      (EL:GenerationVerify 'EL:DLSubmissionCurrent (list result) result 'DEVICE_LIBRARY_CHANGED "�豸���ѱ仯����ǰ���뱣��"))
    "�豸���ѱ仯����ǰ���뱣������ˢ�¿Ⲣ���º˶Ժ󱣴档")
  (setq record (EL:InputRecord record)
    context (EL:TransactionVerifiedStore 'EL:StoreWrite (list (EL:StorePutDiagram record store))))
  (if (and (equal T (EL:Get 'outcome context))
      (equal record (EL:DiagramForPanel (EL:Get 'panel result) (EL:TransactionVerifiedRead context))))
    (progn (setq *EL:LastSavedDraftId* (EL:Get 'diagram-id record)) T)))
(defun EL:InvokeCCKK2 (result cfg powers capacity / *EL:CCKK2Request*)
  (setq *EL:CCKK2Request* (list result cfg powers capacity)) (c:CCKK2))
(defun EL:CCKK2FromPanel (request / result)
  (setq result (car request))
  (princ (strcat "\n���� CCKK2��" (itoa (length (EL:Get 'circuits result)))
    " ��ʵ�ʻ�·�����ʲ��ñ���ͳ�ƣ������������·����"))
  (EL:LogCall "CCKK2" (list (cons 'circuits (length (EL:Get 'circuits result)))
      (cons 'watts (mapcar '(lambda (row) (EL:Get 'watts row)) (EL:Get 'circuits result))))
    'EL:SyncDiagram (append request '(T T))))
(defun EL:EditPanel (result cfg / next context)
  ;; Date: 2026-10-14. Device editing remains in the circuit panel.
  (while result
    (EL:RememberStartPanel (EL:Get 'panel result) (EL:PanelNumber result))
    (setq *EL:StartPickContext* (EL:Put 'record
      (EL:DiagramForPanel (EL:Get 'panel result) (EL:StoreForResult result)) *EL:StartPickContext*))
    (setq *EL:Result* result *EL:FixedConfig* cfg)
    (setq next (EL:EditPanelOnce result cfg))
    (if (setq context (EL:Get 'library-suspended next))
      (setq *EL:DLParentContext* context *EL:DLParentContinue* 'EL:DLResumePanel))
    (if (setq context (EL:Get 'retry-panel next))
      (setq result (EL:Get 'result context) cfg (EL:Get 'config context) *EL:DLResume* context)
      (setq result nil)))
  next)
(defun EL:EditPanelOnce (result cfg)
  ;; Date: 2026-10-21. Share template work only inside this controlled call.
  (EL:WithTemplateScope 'EL:EditPanelOnceWork (list result cfg)))
(defun EL:EditPanelOnceWork (result cfg / *error* store record powers capacity edited prepared saved draft-saved ownlog syncable template resolved perf retry-inputs *EL:GenerationPreflight* *EL:LastSavedDraftId* *EL:LastGeneratedId* *EL:PlacementOnly*)
  (defun *error* (msg)
    (EL:LogFailure msg)
    (vl-catch-all-apply 'EL:ClearGapPreview nil)
    (vl-catch-all-apply 'EL:ClearPickHighlights nil)
    (vl-catch-all-apply 'EL:ReleasePowerUI nil)
    (if msg (princ (strcat "\n�������ֹͣ���ѱ�����������ڱ�ͼ��" msg)))
    (EL:PerfFinish 'failed) (princ))
  (setq ownlog (not *EL:LogActive*))
  (if ownlog (EL:LogStart))
  (EL:LogEvent "EDIT_PANEL" (list (cons 'panel (EL:Get 'panel result))))
  (setq store (cond ((EL:LogCall "READ_STORE" nil 'EL:StoreForResult (list result))) (T (EL:StoreInitial)))
    record (cond ((EL:RecordForResult result store)) (T (EL:NewRecord (EL:Get 'panel result) store))))
  (setq retry-inputs (and *EL:DLResume* (EL:Get 'retry-generation *EL:DLResume*)))
  (if (and *EL:DLResume* (equal (EL:Get 'panel (EL:Get 'result *EL:DLResume*)) (EL:Get 'panel result)))
    (setq prepared (EL:Get 'result *EL:DLResume*) powers (EL:Get 'powers *EL:DLResume*)
      cfg (EL:Get 'config *EL:DLResume*) capacity (EL:Get 'capacity *EL:DLResume*)
      *EL:DLResume* nil)
    (progn
      (setq powers (EL:FixedPowers record)
        prepared (EL:LogCall "PREPARE_PANEL" (list (cons 'diagram-id (EL:Get 'diagram-id record)))
          'EL:PreparedResult (list result
            (if (EL:Get 'draft-circuits record) (EL:Put 'rows (EL:Get 'draft-circuits record) record) record))))
      (setq capacity (EL:CapacityDefault
        (if (EL:Get 'draft-circuits record) (EL:Get 'draft-capacity record) (EL:Get 'capacity-option record)))
        template (EL:Get 'template cfg))
      (if (not (EL:TemplateReady template cfg))
        (setq template (if (EL:TemplateReady (EL:Get 'template (EL:Get 'config record)) cfg)
          (EL:Get 'template (EL:Get 'config record)) (EL:Get 'template record))))
      (if (not (EL:TemplateReady template cfg)) (setq template (EL:Get 'fixed-template store)))
      (setq cfg (EL:Put 'template template cfg))))
  ;; ���ڣ�2026-10-23������ʧ�����Ը�����ʾֵ����ˢ���豸��Ĭ�Ϲ��ʡ�
  (if (not retry-inputs)
    (setq *EL:DLSessionSnapshot* (EL:DLSnapshot)
      resolved (EL:DLPrepare prepared powers *EL:DLSessionSnapshot* nil)
      prepared (EL:Get 'result resolved) powers (EL:Get 'powers resolved)))
  (setq edited (EL:LogCall "PANEL_DIALOG" (list (cons 'panel (EL:Get 'panel result)))
    'EL:PanelDialog (list prepared cfg powers capacity)))
  (if (and edited (not (EL:Get 'pick-panel edited)) (not (EL:Get 'library-suspended edited)))
    (progn
      ;; Date: 2026-10-21. Starts after the dialog; excludes save and placement.
      (setq perf (EL:PerfBegin "PANEL_SUBMIT_PREPARE"))
      (setq result (EL:Get 'result edited) powers (EL:Get 'powers edited)
        capacity (EL:Get 'capacity edited) cfg (EL:Get 'config edited)
        result (if (EL:Get 'generate edited) (EL:GenerationResult result) result)
        syncable (and (or (EL:Get 'generation-warning-mode result)
            (and (EL:Get 'can-generate result) (EL:CircuitNumbersReady result)))
          (EL:SelectionsReady result capacity) (EL:TemplateReady (EL:Get 'template cfg) cfg)))
      (EL:LogEvent "PANEL_SUBMIT" (list (cons 'generate (EL:Get 'generate edited))
        (cons 'syncable syncable) (cons 'panel (EL:Get 'panel result))))
      (EL:PerfMark "panel-submit") (EL:PerfCount "panel-submits" 1)
      (EL:PerfSet "actual-circuits" (length (EL:Get 'circuits result)))
      (if (EL:Get 'generation-warning-mode result)
        (EL:GenerationVerify 'EL:RememberPanelPowers (list result powers) result 'INPUT_CACHE_PENDING "���书�ʻ���δд�룬��ǰ���뱣��")
        (EL:RememberPanelPowers result powers))
      (if (and (not (assoc 'device-library result)) (not (if (EL:Get 'generation-warning-mode result)
          (EL:GenerationVerify 'EL:SaveNamePowers (list powers) result 'POWER_CACHE_PENDING "ͼ�鹦�ʻ���δд�룬��ǰ���뱣��")
          (EL:SaveNamePowers powers))))
        (princ "\n���ʿ�д��ʧ�ܣ��뱣����ǰ������ֵ�������Ŀ¼д��Ȩ�ޡ�"))
      (if (and (EL:GenerationVerify 'EL:DLSubmissionCurrent (list result) result 'DEVICE_LIBRARY_CHANGED "�豸���ѱ仯����ǰ���뱣��")
          (or (not (EL:Get 'generate edited))
            (EL:GenerationVerify 'EL:NumberInputsCurrent (list result) result 'SOURCE_NUMBER_CHANGED "ƽ�����ѱ仯��ԭʼ���֤�ݱ���")))
        (progn
          (EL:PerfEnd perf 'returned)
          ;; Date: 2026-10-15. Save inputs once before placement. A successful
          ;; placement keeps output associations in memory for explicit export.
          (setq *EL:Result* result *EL:FixedConfig* cfg
            saved (if (EL:Get 'generation-warning-mode result)
              (vl-catch-all-apply 'EL:SaveDraft (list result cfg powers capacity)) (EL:SaveDraft result cfg powers capacity)))
          (if (vl-catch-all-error-p saved)
            (progn (EL:GenerationCheck nil result 'INPUT_SAVE_PENDING (strcat "�ݸ�д��δ��ɣ�" (vl-catch-all-error-message saved)))
              (setq saved nil)))
          (setq draft-saved saved)
          (if (and (or saved (EL:Get 'generation-warning-mode result)) (EL:Get 'generate edited))
            (if syncable
              (progn
                (if (not saved)
                  (progn
                    (setq result (EL:Put 'generation-input-save-pending T result))
                    (EL:GenerationCheck nil result 'INPUT_SAVE_PENDING "�����¼��δ���棬�ѱ���������ʾֵ")))
                (setq *EL:GenerationPreflight* (list (namedobjdict) result cfg)
                  *EL:PlacementOnly* T)
                (setq saved (EL:InvokeCCKK2 result cfg powers capacity)))
              (progn
                (setq saved nil)
                (princ "\nϵͳͼ���������δ׼����ɣ���ǰ���뱣��������ԭ����ɼ�鲢���ԡ�")
                (EL:GenerationVerify 'EL:MarkStale (list (EL:Get 'panel result) 'review-or-template-pending)
                  result 'TEMPLATE_PENDING "ϵͳͼ����������˶ԣ���ǰ���뱣��"))))
          (if saved
            (princ (cond ((not draft-saved) "\nϵͳͼ�����ɣ������¼��δд�룬��ǰ��ʾֵ�����ڱ��λỰ��")
              ((EL:Get 'load-error (EL:Get 'device-library result))
                "\n��ǰ�����ѱ������豸������������ʾ���ر�ͼֽǰ�뱣�� DWG��")
              (T "\n��ǰ�����ѱ��浽��ͼ���ر�ͼֽǰ�뱣�� DWG��")))
            (princ "\n���α��������δ��ɣ���鿴�Ϸ�ԭ������ԡ�")))
        (progn
          (EL:PerfEnd perf 'returned)
          (EL:MarkStale (EL:Get 'panel result) 'source-changed)
          (EL:PerfInput 'alert (list (if (EL:DLSubmissionCurrent result)
            "ƽ�����ѱ仯��������ʰȡ����ǰ�����ѳ��Ե�����ס��"
            "�豸���ѱ仯������豸�Ⲣ���º˶ԣ���ǰ�����ѳ��Ե�����ס��")))))))
  (EL:ClearPickHighlights)
  (if ownlog (EL:LogFinish (if edited 'panel-accepted 'panel-cancelled)))
  (cond ((or (EL:Get 'pick-panel edited) (EL:Get 'library-suspended edited)) edited)
    ((and (EL:Get 'generate edited) (not saved))
      (princ "\n������δ��ɣ��ѷ���ԭ��壬ʶ���������ʺ��������֣���ֱ�����Ի�رա�")
      (list (cons 'retry-panel (list '(retry-generation . T) (cons 'result result) (cons 'config cfg)
        (cons 'powers powers) (cons 'capacity capacity)))))))
(defun EL:PublishDiagram (result cfg / store record powers capacity)
  (setq store (EL:StoreForResult result) record (EL:RecordForResult result store))
  (if record
    (progn
      (setq capacity (cond ((EL:Get 'capacity-option record)) (T 'cap300)) powers (EL:Get 'powers record))
      (if (equal (EL:Get 'engine result) 'fixed)
        (setq powers (EL:FixedPowers record) result (EL:PanelCompute result powers cfg))
        (setq result (EL:BoxStatistics result cfg (EL:LoadLibrary) nil)))
      ;; Date: 2026-10-14. Background statistics retain a draft. Only an
      ;; explicit Generate action places a new system diagram.
      (EL:SaveDraft result cfg powers capacity))) result)
;; Date: 2026-10-10. Empty recognition is a user-visible outcome, not a panel error.
(defun EL:PickedDevicesReady (result / ids circuit message)
  (foreach circuit (EL:Get 'circuits result) (setq ids (append ids (EL:Get 'devices circuit))))
  (if ids T
    (progn
      (setq message "δʶ�������豸����ǰ��������ֻ�е��߻�δ�ӵ���ʶ���豸�����鵼�����Ӽ��豸ͼ�������ʰȡ������δ���������ϵͳͼ��")
      (EL:LogEvent "NO_CONNECTED_DEVICES" (list (cons 'panel (EL:Get 'panel result))
        (cons 'circuits (length (EL:Get 'circuits result))) (cons 'message message)))
      (princ (strcat "\n" message)) (EL:PerfInput 'alert (list message)) nil)))
;; Date: 2026-10-13. Do not silently create a second diagram when old source binding is absent.
(defun EL:RepickRecord (panel store / record)
  ;; Date: 2026-10-14. The current source draft alone supplies prior inputs.
  (if (not store) (setq store (EL:StoreInitial)))
  (setq record (EL:DiagramForPanel panel store))
  (EL:LogEvent "SOURCE_DRAFT" (list (cons 'source-panel panel)
    (cons 'diagram-id (EL:Get 'diagram-id record))))
  record)
(defun EL:RepickConfig (cfg record panel / trunk)
  (if (setq trunk (EL:Get 'concentrated-trunk (EL:Get 'config record)))
    (progn
      (EL:Require (handent trunk) "�ѱ���ļ��������߲����ڣ�������ʰȡ���������ߣ�ԭϵͳͼ������")
      (setq cfg (EL:Put 'concentrated-trunk trunk (EL:Put 'auto-panel panel cfg)))))
  (if (EL:Get 'template (EL:Get 'config record))
    (setq cfg (EL:Put 'template (EL:Get 'template (EL:Get 'config record)) cfg))) cfg)
;; Date: 2026-10-13. Panel identity and explicit circuit starts share one flow.
(defun EL:StartPickContext ()
  (if (and *EL:StartPickContext* (equal (EL:Get 'owner *EL:StartPickContext*) (namedobjdict))
      (handent (EL:Get 'panel *EL:StartPickContext*))) *EL:StartPickContext*))
(defun EL:RememberStartPanel (panel number / record)
  (if (and (EL:StartPickContext) (equal panel (EL:Get 'panel *EL:StartPickContext*)))
    (setq record (EL:Get 'record *EL:StartPickContext*)))
  (setq *EL:StartPickContext* (list (cons 'owner (namedobjdict))
    (cons 'panel panel) (cons 'number number) (cons 'record record))))
(defun EL:PickStartPanel (/ pick panel number record)
  (if (setq pick (EL:PickModel 'panel "\nʰȡ����䣺"))
    (progn
      (setq panel (cdr (assoc 5 (entget (car pick)))))
      (EL:Require (not (EL:ManagedEntity (car pick))) "��ѡ��ƽ��ͼ����䣬����ͳ��ϵͳͼ�����")
      (setq number (EL:PickPanelNumber))
      (setq record (EL:RepickRecord panel (EL:StoreIndex)))
      (if (and (equal number "���ޱ��") (EL:Get 'panel-number record))
        (setq number (EL:Get 'panel-number record)))
      (EL:RememberStartPanel panel number)
      (setq *EL:StartPickContext* (EL:Put 'record record *EL:StartPickContext*))
      (setq *EL:StartPickResume* nil *EL:Result* nil *EL:DeviceResult* nil) T)))
(defun EL:StartPickReturn ()
  (if (and *EL:StartPickResume* (EL:StartPickContext)
      (equal (EL:Get 'panel (EL:Get 'result *EL:StartPickResume*))
        (EL:Get 'panel (EL:StartPickContext))))
    (progn (setq *EL:DLResume* *EL:StartPickResume* *EL:StartPickResume* nil)
      (EL:EditPanel (EL:Get 'result *EL:DLResume*) (EL:Get 'config *EL:DLResume*)))))
(defun EL:FixedStatPick (/ *error* outcome)
  (defun *error* (msg)
    (EL:LogFailure msg) (vl-catch-all-apply 'EL:ClearGapPreview nil)
    (vl-catch-all-apply 'EL:ClearPickHighlights nil) (vl-catch-all-apply 'EL:ReleasePowerUI nil)
    (if msg (princ (strcat "\nͳ����ֹͣ��" msg))) (EL:PerfFinish 'failed) (princ))
  (EL:LogStart)
  (if (EL:EnsureRoot)
    (progn
      (EL:LogAttach)
      (setq outcome (EL:MeasuredCatch 'EL:PickStartPanel nil))
      (EL:ClearPickHighlights)
      (if (vl-catch-all-error-p outcome)
        (progn (EL:LogFailure (vl-catch-all-error-message outcome)) (setq outcome nil)))
      (if outcome (EL:FixedStartPick)
        (progn (EL:LogFinish 'panel-pick-cancelled) (EL:StartPickReturn))))))
(defun EL:StartPickEnd (wire point / a b da db)
  (setq a (car (EL:Get 'ends wire)) b (cadr (EL:Get 'ends wire))
    da (EL:Norm (EL:V- point (EL:Get 'point a))) db (EL:Norm (EL:V- point (EL:Get 'point b))))
  (if (> (abs (- da db)) (EL:GapEpsilon)) (if (< da db) a b)))
(defun EL:StartPickArrow (wire ep / segment a b v tip wing)
  (setq segment (if (equal (cadr (EL:Get 'key ep)) 'start) (car (EL:Get 'segments wire))
    (reverse (EL:Last (EL:Get 'segments wire))))
    a (car segment) b (cadr segment) v (EL:V* 0.35 (EL:V- b a)) tip (EL:V+ a v)
    wing (EL:V* 0.25 (list (- (cadr v)) (car v) 0.0)))
  (EL:DrawTransient a tip 2)
  (EL:DrawTransient tip (EL:V+ (EL:V- tip (EL:V* 0.3 v)) wing) 2)
  (EL:DrawTransient tip (EL:V- (EL:V- tip (EL:V* 0.3 v)) wing) 2))
(defun EL:PickCircuitStarts (cfg / pick data wire point ep row starts styles layers)
  (princ "\n����ʰȡ����·��ʼ���ߣ�����������и��ߵ�һ�˵�ѡ����ɫ��ͷ���豸�ˣ��ظ�ʰȡ���޸ķ���Enter ��ɡ�")
  (while (setq pick (EL:PickModel 'wire "\nʰȡ��·��ʼ�˵��ߣ��������һ�ˣ�Enter ��ɣ���"))
    (setq data (entget (car pick)) wire (EL:WireRecord (car pick) cfg) ep nil)
    (cond
      ((or (EL:ManagedEntity (car pick)) (equal (cdr (assoc 60 data)) 1)
          (not (EL:PresetMember (cdr (assoc 8 data)) (EL:Get 'wire-layers cfg))))
        (princ "\n��ѡ��Ԥ�赼��ͼ���ϵĿɼ�ƽ�浼�ߡ�"))
      ((or (EL:Get 'issues wire) (/= (length (EL:Get 'ends wire)) 2))
        (princ "\n��ѡ����Ч�� LINE �򿪷Ŷ���ߡ�"))
      (T
        (setq point (trans (cadr pick) 1 0) ep (EL:StartPickEnd wire point))
        (while (and (not ep) (setq point (EL:PerfInput 'getpoint
            (list "\n������ȷ�����ڿ���������и��ߵĶ˵㸽����һ�£�Enter ��������"))))
          (setq ep (EL:StartPickEnd wire (trans point 1 0))))
        (if ep
          (progn
            (setq row (list (cons 'wire (EL:Get 'id wire)) (cons 'end (cadr (EL:Get 'key ep)))
              (cons 'point (EL:Get 'point ep)))
              starts (append (vl-remove-if '(lambda (old) (equal (EL:Get 'wire old) (EL:Get 'wire row))) starts) (list row))
              styles (EL:Unique (cons (EL:WireStyle data) styles))
              layers (EL:Unique (cons (cdr (assoc 8 data)) layers)))
            (EL:LogEvent "CIRCUIT_START_PICK" row)
            (princ (strcat "\n��ѡ " (itoa (length starts)) " ����·��ʼ���ߡ�"))))))
    (EL:ClearGapPreview) (EL:ClearPickHighlights)
    (foreach row starts
      (EL:HighlightPick (handent (EL:Get 'wire row)))
      (setq wire (EL:WireRecord (handent (EL:Get 'wire row)) cfg)
        ep (EL:By 'key (list (EL:Get 'wire row) (EL:Get 'end row)) (EL:Get 'ends wire)))
      (EL:StartPickArrow wire ep)))
  (if starts (EL:Put 'circuit-starts starts (EL:Put 'concentrated-trunk nil
    (EL:Put 'wire-styles styles (EL:Put 'wire-layers layers cfg))))))
(defun EL:StartPickRun (/ context panel cfg result record saved-config)
  (setq context (EL:StartPickContext) panel (EL:Get 'panel context) record (EL:Get 'record context))
  (EL:Require context "���ȵ����ʰȡ����䡱��ѡ������ͱ�š�")
  (EL:Require (and (equal (cdr (assoc 0 (entget (handent panel)))) "INSERT")
    (not (EL:ManagedEntity (handent panel)))) "�������ʧЧ��������ʰȡ����䡣")
  (setq saved-config (EL:LoadConfig)
    cfg (EL:Put 'roles (EL:Get 'roles saved-config) (EL:Put 'auto-panel panel (EL:Put 'template (EL:Get 'template saved-config)
    (EL:Put 'params (EL:FixedRecognitionParams saved-config) (EL:PresetConfig (EL:DefaultConfig (EL:DrawingID))))))))
  (if (EL:Get 'template (EL:Get 'config record))
    (setq cfg (EL:Put 'template (EL:Get 'template (EL:Get 'config record)) cfg)))
  (if (and (setq cfg (EL:PresetReady (handent panel) cfg)) (setq cfg (EL:PickCircuitStarts cfg)))
    (progn
      (EL:ClearGapPreview) (EL:ClearPickHighlights)
      (EL:LogEvent "PICKS" (list (cons 'panel panel) (cons 'circuit-starts (EL:Get 'circuit-starts cfg))))
      (setq result (EL:LogCall "RECOGNIZE_STARTS" (list panel) 'EL:RecognizeFixed (list cfg panel))
        result (EL:Put 'panel-number (EL:Get 'number context) result))
      (if (EL:PickedDevicesReady result) (list result cfg)))))
(defun EL:StartPickResumeResult (result cfg / context old record key store)
  (if (and (setq context *EL:StartPickResume*)
      (equal (EL:Get 'panel (setq old (EL:Get 'result context))) (EL:Get 'panel result)))
    (progn
      (setq store (cond ((EL:StoreForResult result)) (T (EL:StoreInitial)))
        record (cond ((EL:RecordForResult result store))
          (T (EL:NewRecord (EL:Get 'panel result) store)))
        record (EL:Put 'draft-circuits (EL:Get 'circuits old)
          (EL:Put 'powers (EL:Get 'powers context) (EL:DLPersist old record))))
      (foreach key '(block-ground capacity-source)
        (if (assoc key old) (setq result (EL:Put key (EL:Get key old) result))))
      (setq result (EL:PreparedResult result record)
        *EL:DLResume* (EL:Put 'result result (EL:Put 'config cfg context))))) result)
(defun EL:FixedStartPick (/ *error* outcome next)
  (defun *error* (msg)
    (EL:LogFailure msg) (vl-catch-all-apply 'EL:ClearGapPreview nil)
    (vl-catch-all-apply 'EL:ClearPickHighlights nil) (vl-catch-all-apply 'EL:ReleasePowerUI nil)
    (if msg (princ (strcat "\nʰȡ��ֹͣ�������ͱ�ű�����" msg))) (EL:PerfFinish 'failed) (princ))
  (if (not *EL:LogActive*) (EL:LogStart))
  (if (EL:EnsureRoot)
    (progn (EL:LogAttach)
      (setq outcome (EL:MeasuredCatch 'EL:StartPickRun nil))
      (EL:ClearGapPreview) (EL:ClearPickHighlights)
      (if (vl-catch-all-error-p outcome)
        (progn (EL:LogFailure (vl-catch-all-error-message outcome))
          (princ (strcat "\nʰȡ��ֹͣ�������ͱ�ű�����" (vl-catch-all-error-message outcome))) (setq outcome nil)))
      (if outcome
        (progn
          (setq outcome (list (EL:StartPickResumeResult (car outcome) (cadr outcome)) (cadr outcome))
            *EL:StartPickResume* nil next (EL:EditPanel (car outcome) (cadr outcome))))
        (setq next (EL:StartPickReturn)))
      (EL:LogFinish 'command-finished) next)))
;; Date: 2026-10-10. Reuse an exact saved trunk association; first use identifies the real panel.
(defun EL:TrunkSavedPanel (trunk store / ids row)
  (foreach row (EL:Get 'diagrams store)
    (if (equal trunk (EL:Get 'concentrated-trunk (EL:Get 'config row)))
      (setq ids (cons (EL:Get 'source-panel-handle row) ids))))
  (setq ids (EL:Unique ids))
  (if (= (length ids) 1) (car ids)))
(defun EL:FixedTrunkPick (/ *error* pick trunk panel cfg result record next data id number saved-config)
  (defun *error* (msg)
    (EL:LogFailure msg)
    (vl-catch-all-apply 'EL:ClearPickHighlights nil)
    (vl-catch-all-apply 'EL:ReleasePowerUI nil)
    (if msg (princ (strcat "\n����������ͳ����ֹͣ��" msg))) (EL:PerfFinish 'failed) (princ))
  (setq *EL:Result* nil *EL:DeviceResult* nil)
  (EL:LogStart)
  (if (and (EL:EnsureRoot) (progn (EL:LogAttach) T)
      (setq pick (EL:PickModel 'wire "\nʰȡ�����·������ӵļ��и��ߣ�")))
    (progn
      (setq trunk (car pick) data (entget trunk) id (cdr (assoc 5 data)))
      (EL:Require (and (not (EL:ManagedEntity trunk)) (not (equal (cdr (assoc 60 data)) 1)))
        "��ѡ��ƽ��ͼ�пɼ��ļ��и��ߡ�")
      (setq panel (EL:TrunkSavedPanel id (EL:StoreRead)))
      (if (or (not panel) (not (handent panel)))
        (progn
          (princ "\n�״�ʹ�ô˸��ߣ��벹��ʵ������䣻������Զ����ù�����")
          (setq pick (EL:PickModel 'panel "\nʰȡ�˼��и�������������䣨Enter ȡ������")
            panel (if pick (cdr (assoc 5 (entget (car pick))))))))
      (if panel
        (progn
          (EL:Require (and (equal (cdr (assoc 0 (entget (handent panel)))) "INSERT")
            (not (EL:ManagedEntity (handent panel)))) "��Դ�������Ч��Ϊϵͳͼ�����")
          (setq number (EL:PickPanelNumber))
          (setq saved-config (EL:LoadConfig)
            cfg (EL:Put 'roles (EL:Get 'roles saved-config) (EL:Put 'template (EL:Get 'template saved-config)
              (EL:Put 'params (EL:FixedRecognitionParams saved-config) (EL:PresetConfig (EL:DefaultConfig (EL:DrawingID)))))))
          (EL:Require (EL:PresetMember (cdr (assoc 8 data)) (EL:Get 'wire-layers cfg))
            "���и��߲���Ԥ�赼��ͼ�㣬������ ELPRESET �˶ԡ�")
          (if (setq cfg (EL:PresetReady (handent panel) cfg))
            (progn
              (setq cfg (EL:Put 'concentrated-trunk id (EL:Put 'auto-panel panel
                  (EL:Put 'wire-styles (list (EL:WireStyle data))
                    (EL:Put 'wire-layers (list (cdr (assoc 8 data))) cfg))))
                result (EL:LogCall "RECOGNIZE_TRUNK" (list panel id) 'EL:RecognizeFixed (list cfg panel))
                result (EL:Put 'panel-number number result))
              (princ (strcat "\n���и�����ʶ�� " (itoa (length (EL:Get 'circuits result)))
                " �����ߣ�������Ӷ����ų������ò鿴ȫ����·�˶ԡ�"))
              (setq *EL:Result* result *EL:FixedConfig* cfg)
              (if (EL:PickedDevicesReady result) (setq next (EL:EditPanel result cfg))
                (setq *EL:Result* nil next nil)))
            (progn (EL:ClearPickHighlights) (setq next nil)))))))
  (EL:ClearPickHighlights) (EL:LogFinish 'command-finished) next)
(defun c:ELGEN (/ *error* cfg result record powers capacity perfowner)
  (defun *error* (msg)
    (redraw) (EL:ClearPickHighlights)
    (if *EL:Result* (vl-catch-all-apply 'EL:MarkStale (list (EL:Get 'panel *EL:Result*) 'update-failed)))
    (if msg (princ (strcat "\n������ϵͳͼֹͣ��" msg))) (EL:PerfFinish 'failed) (princ))
  (setq perfowner (EL:PerfStart "ELGEN") *EL:DiagnosticsDeferred* T)
  (if (and *EL:Result* (EL:EnsureRoot))
    (progn
      (setq result *EL:Result* record (EL:RecordForResult result (EL:StoreRead)))
      (if (equal (EL:Get 'engine result) 'fixed)
        (progn
          (setq cfg *EL:FixedConfig* powers (EL:FixedPowers record) result (EL:PanelCompute result powers cfg))
          (if (not (EL:Get 'template cfg)) (setq cfg (EL:Put 'template (EL:Get 'template (EL:LoadConfig)) cfg))))
        (progn
          (princ "\n����ʹ�ø߼����̰����ݱ���Ĺ��ʣ�����д�밴�����������ʿ⡣")
          (setq cfg (EL:LoadConfig) result (EL:BoxStatistics result cfg (EL:LoadLibrary) nil))))
      (setq capacity (cond ((EL:Get 'capacity-option record)) (T 'cap300)))
      (if (equal (EL:Get 'engine result) 'fixed)
        (EL:EditPanel result cfg)
        (EL:SyncDiagram result cfg powers capacity T T)))
    (princ "\n�������� ELSTAT �� ELTRACE��"))
  (if perfowner (EL:PerfFinish 'command-finished)) (princ))

(defun EL:FixedStat (/ *error* next perfowner context)
  (defun *error* (msg)
    (EL:PanelLifecycle "command-error" (list
      (cons "error-at" (EL:Get "panel-lifecycle-stage" *EL:PerfMetrics*)) (cons "error" msg)))
    (EL:LogFailure msg)
    (vl-catch-all-apply 'EL:ReleasePowerUI nil)
    (if msg (princ (strcat "\nͳ����ֹͣ��" msg)))
    (EL:PerfFinish 'failed) (princ))
  (setq perfowner (EL:PerfStart "ELSTAT") *EL:DiagnosticsDeferred* T)
  (EL:PanelLifecycle "command-entry" '(("entry" . "ELSTAT") ("requested" . T)))
  ;; Date: 2026-10-14. Open the unified panel before asking for a CAD pick.
  (if (EL:EnsureRoot)
    (progn
      (EL:PanelLifecycle "home-requested" nil)
      (setq next (EL:PerfCall "PANEL_HOME" 'EL:PanelDialog (list nil nil nil nil)))
      (EL:PanelLifecycle "home-returned" (list (cons "pick-requested" (EL:Get 'pick-panel next)))))
    (EL:PanelLifecycle "root-unavailable" '(("not-shown-reason" . "root-unavailable"))))
  (if (setq context (EL:Get 'library-suspended next))
    (progn (setq *EL:DLParentContext* context *EL:DLParentContinue* 'EL:DLResumeHome)
      (setq next nil)))
  (while (EL:Get 'pick-panel next)
    (setq next (if (equal (EL:Get 'pick-panel next) 'trunk)
      (EL:PerfCall "PICK_STARTS" 'EL:FixedStartPick nil)
      (EL:PerfCall "PICK_PANEL" 'EL:FixedStatPick nil))))
  (if perfowner (EL:PerfFinish 'command-finished)) (princ))
;; Date: 2026-10-14. Continue the same opening panel after an async graphic pick.
(defun EL:DLResumeHome ()
  (setq *EL:DLParentContext* nil *EL:DLParentContinue* nil *EL:DLSessionSnapshot* nil)
  (EL:FixedStat))
(defun EL:RememberDiagramDiagnostic (record store)
  ;; Date: 2026-10-15. One successful output per open DWG, no file or XRecord
  ;; write. A failed/cancelled placement never replaces the previous output.
  ;; Date: 2026-10-21. Keep the successful association's own run identity;
  ;; a later cancelled recognition must not inherit its success evidence.
  (if *EL:PerfActive* (setq *EL:PerfOutcome* 'diagram-generated))
  (setq *EL:DiagramDiagnostics* (EL:Put (namedobjdict)
    (list (cons 'record record) (cons 'run-id (if *EL:PerfActive* *EL:PerfRunID*))
      (cons 'captured-at (getvar "CDATE")) (cons 'store
      (list '(schema-version . 1) (cons 'drawing-uuid (EL:Get 'drawing-uuid store)))))
    *EL:DiagramDiagnostics*)) nil)
(defun EL:DiagnosticRequire (condition message)
  ;; Preserve the actionable reason when AutoLISP EXIT becomes a generic abort.
  (if (not condition) (setq *EL:DiagnosticError* message))
  (EL:Require condition message))
(defun EL:DiagnosticFailure (outcome)
  (if *EL:DiagnosticError* *EL:DiagnosticError* (vl-catch-all-error-message outcome)))
(defun EL:DiagnosticRecord (store / record pick tag handle)
  (if *EL:Result*
    (setq record (EL:DiagramForPanel (EL:Get 'panel *EL:Result*) store)))
  (if (and record (not (EL:Get 'panel-output-handle record))) (setq record nil))
  (if (not record)
    (if (setq pick (EL:PickEntity "\nѡ��Ҫ�������ܹ�ϵͳͼ���塢��·�����֣�Enter ȡ������"))
      (progn
        (setq handle (cdr (assoc 5 (entget (car pick)))) tag (EL:DiagramTag (car pick))
          record (EL:By 'diagram-id (cdr (nth 1 tag)) (EL:Get 'diagrams store)))
        (EL:DiagnosticRequire (and record (equal (cdr (car tag)) (EL:Get 'drawing-uuid store))
          (equal (cdr (nth 4 tag)) handle)
          (EL:OwnedEntity handle store record (cdr (nth 2 tag)) (cdr (nth 3 tag)))
          (member (list handle (cdr (nth 2 tag)) (cdr (nth 3 tag))) (EL:DiagramOutputRefs record)))
          "���Ǳ�ͼԭʼ�ܹܳ�Ա�����ƻ����������ܵ���������¼��")))) record)
(defun EL:DiagnosticRecordValid (record store / ref entity)
  (EL:DiagnosticRequire (and (equal (type (EL:Get 'diagram-id record)) 'STR)
    (/= (EL:Get 'diagram-id record) "")
    (equal (type (EL:Get 'source-panel-handle record)) 'STR)
    (/= (EL:Get 'source-panel-handle record) "")
    (equal (type (EL:Get 'panel-output-handle record)) 'STR)
    (/= (EL:Get 'panel-output-handle record) "")
    (equal (type (EL:Get 'drawing-uuid store)) 'STR)
    (/= (EL:Get 'drawing-uuid store) "")
    (EL:UniqueDiagram store record)) "ϵͳͼ���ݲ��������и��ƹ�����δ������ϸ�����")
  (foreach ref (EL:DiagramOutputRefs record)
    (setq entity (EL:OwnedEntity (car ref) store record (cadr ref) (caddr ref)))
    ;; Exporting is read-only, so a locked layer does not prevent diagnostics.
    (EL:DiagnosticRequire (and entity (equal (cdr (assoc 410 (entget entity))) "Model"))
      "ϵͳͼ��Աȱʧ�����ʧ�䣬δ������ϸ�����")) T)
(defun EL:DiagnosticWindowsPath (path)
  (if path (vl-string-translate "/" "\\" path)))
(defun EL:DiagnosticWriteText (path textdata / stream result closed)
  ;; Date: 2026-10-15. All new diagnostic snapshots are UTF-8, including CAD2020.
  (setq result (vl-catch-all-apply '(lambda ()
    (setq stream (vlax-create-object "ADODB.Stream"))
    (EL:MonitorStreamWrite stream path textdata)) nil))
  (if stream
    (progn
      (setq closed (vl-catch-all-apply 'vlax-invoke-method (list stream 'Close)))
      (vlax-release-object stream)))
  (EL:DiagnosticRequire (and result (not (vl-catch-all-error-p result))
    (not (vl-catch-all-error-p closed)))
    (strcat "����ļ�д��ʧ�ܣ��ڴ������ѱ�����" (EL:DiagnosticWindowsPath path))) T)
(defun EL:DiagnosticProgress (stage / file)
  ;; Date: 2026-10-15. Flush a small checkpoint before each potentially slow file.
  (setq *EL:DiagnosticStage* stage)
  (if *EL:DiagnosticProgressPath*
    (progn
      (princ (strcat "\n��ϵ�����" stage))
      (if (setq file (open *EL:DiagnosticProgressPath* "a"))
        (progn (write-line (strcat (rtos (EL:Tick) 2 0) " " stage) file) (close file))))) nil)
(defun EL:DiagnosticNativeCharset () "gb2312")
(defun EL:DiagnosticNativeText (path / stream outcome)
  ;; Native PRINT writes directly to disk; ADO performs the codepage conversion
  ;; in native code instead of constructing a multi-megabyte LISP print string.
  (setq outcome (vl-catch-all-apply '(lambda ()
    (setq stream (vlax-create-object "ADODB.Stream"))
    (vlax-put-property stream 'Type 2)
    (vlax-put-property stream 'Charset (EL:DiagnosticNativeCharset))
    (vlax-invoke-method stream 'Open nil 0 -1 "" "")
    (vlax-invoke-method stream 'LoadFromFile path)
    (vlax-invoke-method stream 'ReadText -1)) nil))
  (if stream
    (progn (vl-catch-all-apply 'vlax-invoke-method (list stream 'Close))
      (vlax-release-object stream)))
  (EL:DiagnosticRequire (not (vl-catch-all-error-p outcome))
    (strcat "�����ʱ�ļ���ȡʧ�ܣ�" (EL:DiagnosticWindowsPath path))) outcome)
(defun EL:DiagnosticWriteData (path data / tmp file outcome closed)
  ;; Date: 2026-10-15. Do not VL-PRIN1-TO-STRING the entire live graph/store.
  (EL:DiagnosticProgress (strcat "FILE_BEGIN " (vl-filename-base path)))
  (setq tmp (strcat path ".native.tmp")
    outcome (vl-catch-all-apply '(lambda ()
      (setq file (open tmp "w"))
      (EL:DiagnosticRequire file "�޷����������ʱ�ļ���")
      (prin1 data file) (write-line "" file)) nil))
  (if file (setq closed (vl-catch-all-apply 'close (list file))))
  (if (and (not (vl-catch-all-error-p outcome)) (not (vl-catch-all-error-p closed)))
    (setq outcome (vl-catch-all-apply '(lambda ()
      (EL:DiagnosticWriteText path (EL:DiagnosticNativeText tmp))) nil))
    (setq outcome nil))
  (if (findfile tmp) (vl-catch-all-apply 'vl-file-delete (list tmp)))
  (EL:DiagnosticRequire (and (not (vl-catch-all-error-p outcome)) outcome)
    (strcat "�������д��ʧ�ܣ���������ϱ�����ԭĿ¼��" (EL:DiagnosticWindowsPath path)))
  (EL:DiagnosticProgress (strcat "FILE_DONE " (vl-filename-base path))) T)
(defun EL:DiagnosticFields (data keys / result key row)
  (foreach key keys (if (setq row (assoc key data)) (setq result (cons row result))))
  (reverse result))
(defun EL:DiagnosticResult (result / snapshot circuits circuit)
  ;; The persisted input/association is exported separately in full. Live caches
  ;; and expanded geometry are not a second diagnostic record of that input.
  (if result
    (progn
      (setq snapshot (EL:Get 'snapshot result))
      (foreach circuit (EL:Get 'circuits result)
        (setq circuits (cons (EL:DiagnosticFields circuit
          '(id circuit-uid circuit-number number-status watts total-watts complete
            issues wires devices objects seed-key output-order rows groups)) circuits)))
      (append (EL:DiagnosticFields result '(panel drawing engine complete total-watts
          capacity-option capacity-source diagram-id excluded-seeds start-link-exclusions))
        (list '(diagnostic-scope . business-fields)
          '(omitted-live-fields snapshot-geometry network-proof device-library caches)
          (cons 'snapshot-summary (list (cons 'drawing (EL:Get 'drawing snapshot))
            (cons 'wire-count (length (EL:Get 'wires snapshot)))
            (cons 'block-count (length (EL:Get 'blocks snapshot)))
            (cons 'end-count (length (EL:Get 'ends snapshot)))
            (cons 'issue-count (length (EL:Get 'issues snapshot)))))
          (cons 'circuits (reverse circuits)))))))
(defun EL:DiagnosticFolderAt (base / folder index)
  (setq base (strcat (EL:NormalizeRoot base) "ELDIAG-" (rtos (getvar "CDATE") 2 6))
    folder base index 0)
  (while (or (vl-file-directory-p folder) (findfile (strcat folder ".zip"))
      (findfile (strcat folder ".zip.partial")) (findfile (strcat folder ".zip.status"))
      (findfile (strcat folder ".zip.status.tmp")) (findfile (strcat folder ".zip.cancel")))
    (setq index (1+ index) folder (strcat base "-" (itoa index))))
  (if (vl-mkdir folder) folder))
(defun EL:DiagnosticFolder (/ folder)
  (setq folder (vl-catch-all-apply 'EL:DiagnosticFolderAt (list (strcat *EL:Root* "output/"))))
  (if (or (not folder) (vl-catch-all-error-p folder))
    (setq folder (vl-catch-all-apply 'EL:DiagnosticFolderAt (list (getvar "TEMPPREFIX")))))
  (EL:DiagnosticRequire (and folder (not (vl-catch-all-error-p folder))) "�޷��������Ŀ¼���������Ŀ¼����ʱĿ¼��д��Ȩ�ޡ�")
  folder)
(defun EL:DiagnosticPSQuote (value / index)
  (setq index 0)
  (while (setq index (vl-string-search "'" value index))
    (setq value (strcat (substr value 1 index) "''" (substr value (+ index 2))) index (+ index 2)))
  (strcat "'" value "'"))
(defun EL:DiagnosticEncodedCommand (textdata / stream xml node result object)
  ;; No user path is interpolated into a shell command. PowerShell receives
  ;; UTF-16LE Base64, avoiding WScript expansion of percent signs in paths.
  (setq result (vl-catch-all-apply '(lambda ()
    (setq stream (vlax-create-object "ADODB.Stream"))
    (vlax-put-property stream 'Type 2) (vlax-put-property stream 'Charset "unicode")
    (vlax-invoke-method stream 'Open nil 0 -1 "" "")
    (vlax-invoke-method stream 'WriteText textdata 0)
    (vlax-put-property stream 'Position 0) (vlax-put-property stream 'Type 1)
    (vlax-put-property stream 'Position 2)
    (setq xml (vlax-create-object "MSXML2.DOMDocument.6.0")
      node (EL:StartupUnwrap (vlax-invoke-method xml 'createElement "binary")))
    (vlax-put-property node 'dataType "bin.base64")
    (vlax-put-property node 'nodeTypedValue (vlax-invoke-method stream 'Read -1))
    (vlax-get-property node 'text)) nil))
  (if stream (vl-catch-all-apply 'vlax-invoke-method (list stream 'Close)))
  (foreach object (list stream node xml)
    (if object (vl-catch-all-apply 'vlax-release-object (list object))))
  (EL:DiagnosticRequire (not (vl-catch-all-error-p result))
    (strcat "�޷�׼�����ѹ�����"
      (if (vl-catch-all-error-p result) (vl-catch-all-error-message result) "")))
  (foreach object '("\r" "\n" " " "\t")
    (while (vl-string-search object result) (setq result (vl-string-subst "" object result)))) result)
(defun EL:DiagnosticScriptText (/ path file line parts)
  ;; Date: 2026-10-15. Source installs read the helper; delivered modules
  ;; embed its text so startup never needs to write a PowerShell file.
  (if (and *EL:Root* (setq path (findfile (strcat *EL:Root* "src/diagnostic-bundle.ps1")))
      (setq file (open path "r")))
    (progn
      (while (setq line (read-line file)) (setq parts (cons (strcat line "\r\n") parts)))
      (close file) (EL:MonitorJoin (reverse parts)))))
(defun EL:DiagnosticWait (path milliseconds / started echo outcome file polls)
  ;; Date: 2026-10-15. Only explicit export waits; stop as soon as the worker finishes.
  (setq started (EL:Tick) echo (getvar "CMDECHO") polls 0)
  (setvar "CMDECHO" 0)
  (setq outcome (vl-catch-all-apply '(lambda ()
    (while (and (not (findfile path)) (< polls (/ milliseconds 50))
        (< (EL:PerfDelta started (EL:Tick)) milliseconds))
      (vl-cmdf "_.DELAY" 50) (setq polls (1+ polls)))
    (if (findfile path)
      (progn
        (setq file (open path "r"))
        (EL:DiagnosticRequire file "�޷���ȡ���ѹ��״̬�ļ���")
        (read-line file)))) nil))
  (if file (vl-catch-all-apply 'close (list file)))
  (setvar "CMDECHO" echo)
  (EL:DiagnosticRequire (not (vl-catch-all-error-p outcome))
    (if (vl-catch-all-error-p outcome) (EL:DiagnosticFailure outcome) "")) outcome)
(defun EL:DiagnosticCancelZip (path / file)
  ;; An abandoned worker checks this marker before publishing a ZIP.
  (if (setq file (open path "w")) (progn (write-line "CANCEL" file) (close file))))
(defun EL:DiagnosticZip (folder / script powershell command result path status outcome)
  (EL:DiagnosticProgress "ZIP_PREPARE")
  (setq script (EL:DiagnosticScriptText)
    powershell (strcat (getenv "SystemRoot") "/System32/WindowsPowerShell/v1.0/powershell.exe")
    path (strcat folder ".zip") status (strcat path ".status"))
  (EL:DiagnosticRequire (and script (findfile powershell)) "���ѹ������ȱʧ����ʹ�������������� Windows PowerShell��")
  (EL:DiagnosticProgress "ZIP_ENCODE")
  (setq command (EL:DiagnosticEncodedCommand (strcat "& {\r\n" script "\r\n} -SourceDirectory "
    (EL:DiagnosticPSQuote (EL:DiagnosticWindowsPath folder)))))
  ;; Date: 2026-10-15. CAD2020 fails in WScript.Shell creation/Run on site.
  ;; STARTAPP uses the CAD process launcher, with no WScript COM dependency.
  (EL:DiagnosticProgress "ZIP_LAUNCH STARTAPP")
  (setq result (vl-catch-all-apply 'startapp
    (list (EL:DiagnosticWindowsPath powershell)
      (strcat "-NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -EncodedCommand " command))))
  (EL:DiagnosticRequire (and (not (vl-catch-all-error-p result))
    (equal (type result) 'INT) (> result 0))
    (strcat "�޷��������ѹ������"
      (if (vl-catch-all-error-p result) (vl-catch-all-error-message result) "STARTAPP δ�ɹ�����")
      "��ԭʼ���ϱ����ڣ�" (EL:DiagnosticWindowsPath folder)))
  ;; Do not append to snapshot files while the worker hashes/compresses them.
  (setq *EL:DiagnosticStage* "ZIP_WAIT")
  (setq outcome (vl-catch-all-apply 'EL:DiagnosticWait (list status 30000)))
  (if (or (vl-catch-all-error-p outcome) (not outcome))
    (vl-catch-all-apply 'EL:DiagnosticCancelZip (list (strcat path ".cancel"))))
  (if (not outcome) (EL:DiagnosticProgress "ZIP_TIMEOUT"))
  (EL:DiagnosticRequire (and outcome (not (vl-catch-all-error-p outcome)))
    (if (vl-catch-all-error-p outcome) (EL:DiagnosticFailure outcome)
      (strcat "���ѹ���ȴ����� 30 �룬��ֹͣ�ȴ���ԭʼ���ϱ����ڣ�" (EL:DiagnosticWindowsPath folder))))
  (if (findfile status) (vl-catch-all-apply 'vl-file-delete (list status)))
  (EL:DiagnosticRequire (and (equal outcome "OK") (findfile path) (> (vl-file-size path) 0))
    (strcat "���ѹ��ʧ�ܣ�" outcome "����"
      (if (equal outcome "OK") "ZIP �ļ������ڻ�Ϊ��" "��ϸԭ�����Ŀ¼ bundle-error.txt")
      "��ԭʼ���ϱ����ڣ�" (EL:DiagnosticWindowsPath folder)))
  (EL:DiagnosticWindowsPath path))
(defun EL:DiagnosticRunMetadata (record run / session summary current)
  ;; Date: 2026-10-21. VERIFIED describes only the exported association.
  ;; Match the exact generating run, never a block name, box or old result.
  (setq session (EL:Get (namedobjdict) *EL:DiagramDiagnostics*)
    summary (EL:Get 'summary run)
    current (and record (EL:Get 'run-id summary) (EL:Get 'run-id session)
      (equal record (EL:Get 'record session))
      (equal (EL:Get 'run-id summary) (EL:Get 'run-id session))))
  (list (cons 'run-id (EL:Get 'run-id summary))
    (cons 'run-command-status (EL:Get 'status summary))
    (cons 'run-business-outcome (EL:Get 'last-outcome summary))
    (cons 'association-scope (cond (current 'current-run-generated)
      (record 'recent-success-or-selected) (T 'unavailable)))
    (cons 'association-current-run (if current T nil))
    (cons 'association-run-id (if (and record (equal record (EL:Get 'record session)))
      (EL:Get 'run-id session)))
    (cons 'association-captured-at (if (and record (equal record (EL:Get 'record session)))
      (EL:Get 'captured-at session)))))
(defun EL:DiagnosticBundle (record store logpath issue / folder run files entry source target notes stamp metadata
    *EL:DiagnosticProgressPath*)
  (setq folder (EL:DiagnosticFolder) *EL:DiagnosticExportPath* (EL:DiagnosticWindowsPath folder)
    stamp (rtos (getvar "CDATE") 2 6)
    run (EL:Get (namedobjdict) *EL:DiagnosticRuns*) files '("progress.log")
    *EL:DiagnosticProgressPath* (strcat folder "/progress.log"))
  (EL:DiagnosticProgress "BUNDLE_BEGIN")
  (foreach entry (list (cons "run.eld" run)
      (cons "load.eld" (if *EL:MonitorLoadSummary* (list
        (cons 'summary *EL:MonitorLoadSummary*) (cons 'rows *EL:MonitorLoadRows*)
        (cons 'origin *EL:MonitorLoadOrigin*) (cons 'stamp *EL:MonitorLoadStamp*))))
      (cons "association.eld" record)
      (cons "drawing-store.eld" store) (cons "current-result.eld" (EL:DiagnosticResult *EL:Result*))
      (cons "panel-template.eld" (EL:Get (namedobjdict) *EL:PanelTemplateDiagnostics*)))
    (if (cdr entry)
      (progn (EL:DiagnosticWriteData (strcat folder "/" (car entry)) (cdr entry))
        (setq files (cons (car entry) files)))
      (setq notes (cons (strcat (car entry) "�����λỰû�п������ϡ�\r\n") notes))))
  ;; Historical shared logs are explicitly named; never collect DWGs, assets,
  ;; previous diagnostic archives or unrelated files by a recursive scan.
  (foreach entry (list (cons "timeline.md" logpath)
      ;; Date: 2026-10-22. Explicit current-drawing prototype reports, never a folder scan.
      (cons "cold-probe.json" (car (EL:Get (namedobjdict) *EL:ColdReports*)))
      (cons "cold-comparison.eld" (cadr (EL:Get (namedobjdict) *EL:ColdReports*)))
      (cons "runtime-ELTRACE-debug.log" (strcat *EL:Root* "output/ELTRACE-debug.log"))
      (cons "runtime-ELPERF.log" (strcat *EL:Root* "output/ELPERF.log"))
      (cons "active-ELTRACE-debug.log" *EL:LogPath*)
      (cons "temp-ELTRACE-debug.log" (strcat (getvar "TEMPPREFIX") "ELTRACE-debug.log"))
      (cons "temp-ELPERF.log" (strcat (getvar "TEMPPREFIX") "ELPERF.log")))
    (setq source (cdr entry) target (strcat folder "/" (car entry)))
    (if (and source (findfile source))
      (progn
        (EL:DiagnosticProgress (strcat "COPY_BEGIN " (car entry)))
        (EL:DiagnosticRequire (vl-file-copy source target)
          (strcat "�޷����������־��" (EL:DiagnosticWindowsPath source)))
        (setq files (cons (car entry) files))
        (EL:DiagnosticProgress (strcat "COPY_DONE " (car entry))))
      (setq notes (cons (strcat (car entry) "������δ�������ļ������ڡ�\r\n") notes))))
  (setq metadata (list '(export-format . directory) (cons 'export-time stamp) (cons 'package *EL:PackageMarker*)
    (cons 'drawing (getvar "DWGNAME")) (cons 'drawing-folder (getvar "DWGPREFIX"))
    (cons 'acad-version (getvar "ACADVER")) (cons 'association-status (if record 'verified 'unavailable))
    (cons 'association-issue issue) (cons 'files (append '("README.md" "manifest.eld") (reverse files)))))
  (setq metadata (append metadata (EL:DiagnosticRunMetadata record run)))
  (EL:DiagnosticWriteData (strcat folder "/manifest.eld") metadata)
  (EL:DiagnosticWriteText (strcat folder "/README.md")
    (strcat "# Ӧ�������������\r\n���ڣ�" (substr stamp 1 4) "-" (substr stamp 5 2) "-" (substr stamp 7 2)
      "\r\n״̬����Ͽ������ռ��������˶�״̬�� manifest.eld\r\n\r\n"
      "�����ļ����е����Ϸ���������Ա���ɣ�Ҳ������ѹ�����������޸�ͼֽ��\r\n"
      "timeline.md����ǰͼֽ�����Ч���еĺ�ʱ�������¼�������ʱ���ᡣ\r\n"
      "run.eld��ͬһ�����е������¼��ͼ�ʱԭʼ���ݣ�δ����־�ı��ضϡ�\r\n"
      "load.eld�����λỰ���һ�β�����صļ�ʱ��ԭʼ�������������� run.eld��\r\n"
      "association.eld����ǰͼֽ����ɹ���ͼ��ѡ�о�ϵͳͼ���Ѻ˶Թ�����VERIFIED ��֤������ʶ������ɳɹ���\r\n"
      "manifest.eld �� association-scope/current-run ���ֱ�����������ʷ����������ԭ������״̬��ҵ�����ֱ��¼��\r\n"
      "drawing-store.eld����ǰͼֽ�ѱ����¼��ֻ�����գ����������о�ͼ��Ա�Ѻ˶ԡ�\r\n"
      "current-result.eld����ǰʶ������ҵ���ֶ���Դͼ���������������һ�γɹ���ͼ��ͬ��\r\n"
      "panel-template.eld����ǰͼֽ���һ�����ģ��׼��״̬��ȱ�ԭʼʧ��ԭ�򣬲�����������ϵͳͼ��\r\n"
      "���������¼�ͳ�ͼ���������� drawing-store.eld / association.eld�����ظ�չ���ڴ漸�Ρ�����֤�����豸�⻺�档\r\n"
      "progress.log�����ļ��������㣻�ж�ʱ�ɶ�λ������Ľ׶Ρ�\r\n"
      "runtime / active / temp ��־�����й�����ʷ�ļ������ܺ���ǰ���������ͼֽ���� run.eld Ϊ�����������ݡ�\r\n"
      "manifest.eld���汾��ͼֽ������ʱ�䡢����ҵ������������Χ��״̬���ļ��嵥��\r\n"
      "�������ɵ� .eld / .md Ϊ UTF-8�����Ƶ���ʷ .log ����ԭ���롣\r\n"
      "�ڴ��¼�ڹر�ͼֽ���ٱ�����ȱ�����ϲ���α�첹ȫ��\r\n\r\n"
      (if issue (strcat "������ȡ��˶����⣺" issue "\r\n") "")
      (EL:MonitorJoin (reverse notes))))
  ;; Date: 2026-10-15. Export completes without a child process or ZIP dependency.
  (EL:DiagnosticProgress "BUNDLE_DONE")
  (EL:DiagnosticWindowsPath folder))
(defun EL:DiagnosticOpenFolder (path / outcome)
  (if (and path (or (vl-file-directory-p path) (findfile path)))
    (progn
      (setq outcome (vl-catch-all-apply 'startapp
        (list "explorer.exe" (strcat (if (vl-file-directory-p path) "\"" "/select,\"")
          (EL:DiagnosticWindowsPath path) "\""))))
      (if (or (not outcome) (vl-catch-all-error-p outcome))
        "�޷����ļ��У��밴�������е�����·���ֶ��򿪡�" "�Ѵ�����ļ�����λ�á�"))
    "������ϲ����ڣ������µ�����"))
(defun EL:DiagnosticExport (/ store record path session logpath issue checked)
  (setq *EL:DiagnosticExportMessage* nil *EL:DiagnosticExportPath* nil *EL:DiagnosticError* nil
    *EL:DiagnosticStage* "EXPORT_BEGIN")
  (if (EL:EnsureRoot)
    (progn
      (setq logpath (EL:ExportDiagnosticRun)
        session (EL:Get (namedobjdict) *EL:DiagramDiagnostics*))
      (setq store (EL:MeasuredCatch 'EL:StoreRead nil))
      (if (vl-catch-all-error-p store)
        (setq issue (vl-catch-all-error-message store) store nil))
      (if session
        (setq record (EL:Get 'record session))
        (if (vl-some '(lambda (row) (EL:Get 'panel-output-handle row)) (EL:Get 'diagrams store))
          (progn
            (setq record (EL:MeasuredCatch 'EL:DiagnosticRecord (list store)))
            (if (vl-catch-all-error-p record)
              (setq issue (EL:DiagnosticFailure record) record nil)))))
      (if record
        (progn
          (setq checked (EL:MeasuredCatch 'EL:DiagnosticRecordValid
            (list record (if session (EL:Get 'store session) store))))
          (if (vl-catch-all-error-p checked)
            (setq issue (EL:DiagnosticFailure checked) record nil))))
      (setq *EL:DiagnosticError* nil)
      (setq path (EL:PerfCall "DIAGNOSTIC_EXPORT" 'EL:DiagnosticBundle (list record store logpath issue)))
      (EL:DiagnosticRequire (and (equal (type path) 'STR) (/= path "")) "�������Ŀ¼δ���ɣ��ڴ������ѱ�����")
      (setq
        *EL:DiagnosticExportPath* path
        *EL:DiagnosticExportMessage* (if issue "�ѵ�����������ļ��У������쳣ԭ�����������С�" "�ѵ�����������ļ��У��ɸ���·����򿪲鿴��"))
      (EL:LogEvent "DIAGNOSTIC_EXPORTED" (list (cons 'path path) (cons 'association-issue issue)))
      (princ (strcat "\n��������ļ��У�" path)) path)))
(defun EL:DiagnosticSaveFailure (message / saved stamp notice)
  ;; Date: 2026-10-15. Keep the original failure even if saving its report fails.
  (setq saved *EL:DiagnosticError* stamp (rtos (getvar "CDATE") 2 6)
    notice (strcat "��ϵ���ʧ�ܣ�" message)
    *EL:DiagnosticExportMessage* notice)
  (if (and *EL:DiagnosticExportPath* (vl-file-directory-p *EL:DiagnosticExportPath*))
    (vl-catch-all-apply 'EL:DiagnosticWriteText
      (list (strcat *EL:DiagnosticExportPath* "\\export-error.txt")
        (strcat "���ڣ�" (substr stamp 1 4) "-" (substr stamp 5 2) "-" (substr stamp 7 2)
          "\r\n״̬������ʧ�ܣ���������ϱ���\r\n"
          "export-time: " stamp "\r\npackage: " (vl-prin1-to-string *EL:PackageMarker*)
          "\r\nstage: " (cond (*EL:DiagnosticStage*) (T "UNKNOWN"))
          "\r\n" notice "\r\n"))))
  (setq *EL:DiagnosticError* saved)
  (princ (strcat "\n" notice)) notice)
(defun EL:PanelDiagnosticExport (/ outcome)
  ;; Export outside the DCL callback, then reopen with the same input values.
  ;; Date: 2026-10-16. A retained partial directory is not a successful export.
  (setq *EL:DiagnosticExportSucceeded* nil
    outcome (EL:MeasuredCatch 'EL:DiagnosticExport nil)
    *EL:DiagnosticExportSucceeded* (and (not (vl-catch-all-error-p outcome))
      outcome (equal outcome *EL:DiagnosticExportPath*)))
  (cond
    ((vl-catch-all-error-p outcome)
      (EL:DiagnosticSaveFailure (EL:DiagnosticFailure outcome)))
    (*EL:DiagnosticExportMessage*)
    (T "��ϵ���δ��ɣ���鿴������ԭ��")))
(defun c:ELDIAG (/ *error* perfowner outcome checkpoint failed)
  (defun *error* (message)
    (EL:PerfUnwind checkpoint) (EL:ClearPickHighlights)
    (EL:LogFailure message) (if perfowner (EL:PerfFinish 'failed)) (princ))
  (setq perfowner (EL:PerfStart "ELDIAG") checkpoint *EL:PerfPending*)
  (EL:LogStart)
  (setq outcome (vl-catch-all-apply 'EL:LogCall
    (list "DIAGNOSTIC_COMMAND" nil 'EL:DiagnosticExport nil)))
  (if (vl-catch-all-error-p outcome)
    (progn
      (setq failed T) (EL:PerfUnwind checkpoint)
      (EL:DiagnosticSaveFailure (EL:DiagnosticFailure outcome))
      (EL:LogFailure (EL:DiagnosticFailure outcome)))
    (EL:LogFinish (if outcome 'diagnostic-exported 'diagnostic-not-exported)))
  (EL:ClearPickHighlights)
  (if perfowner (EL:PerfFinish (if failed 'failed (if outcome 'diagnostic-exported 'diagnostic-not-exported)))) (princ))

(defun EL:DiagnosticScriptText () (EL:MonitorJoin '(
"# Date: 2026-10-15. Status: implemented; invoked only by explicit diagnostic export.\nparam([Parameter(Mandatory = $true)][string]$SourceDirectory)\n$ErrorActionPreference = 'Stop'\n$stage = $nul"
"l\n$partial = $null\n$statusPath = $null\n$published = $false\nfunction Complete-ELDiagnostic([string]$result) {\n    [IO.File]::WriteAllText($statusPath + '.tmp', $result, [Text.Encoding]::ASCII)\n"
"    [IO.File]::Move($statusPath + '.tmp', $statusPath)\n}\ntry {\n    $stage = [IO.Path]::GetFullPath($SourceDirectory).TrimEnd('\\', '/')\n    if (-not [IO.Directory]::Exists($stage) -or\n        ["
"IO.Path]::GetFileName($stage) -notmatch '^ELDIAG-[0-9.-]+$') {\n        throw 'Invalid diagnostic staging directory.'\n    }\n    $zipPath = $stage + '.zip'\n    $partial = $zipPath + '.partial'\n "
"   $statusPath = $zipPath + '.status'\n    $cancelPath = $zipPath + '.cancel'\n    if ([IO.File]::Exists($statusPath) -or [IO.File]::Exists($statusPath + '.tmp')) {\n        throw 'Diagnostic com"
"pletion status already exists.'\n    }\n    Add-Type -AssemblyName System.IO.Compression\n    Add-Type -AssemblyName System.IO.Compression.FileSystem\n    if ([IO.File]::Exists($zipPath) -or [IO.F"
"ile]::Exists($partial)) {\n        throw 'Diagnostic archive already exists; nothing was overwritten.'\n    }\n    $files = @([IO.Directory]::GetFiles($stage) | Sort-Object)\n    if ($files.Count "
"-eq 0 -or [IO.Directory]::GetDirectories($stage).Length -ne 0 -or\n        -not [IO.File]::Exists([IO.Path]::Combine($stage, 'README.md'))) {\n        throw 'Incomplete diagnostic staging direct"
"ory.'\n    }\n    # The source is a dedicated snapshot, never the package root or a recursive scan.\n    $stream = [IO.File]::Open($partial, [IO.FileMode]::CreateNew)\n    try {\n        $archive ="
" New-Object IO.Compression.ZipArchive($stream, [IO.Compression.ZipArchiveMode]::Create, $true)\n        try {\n            foreach ($file in $files) {\n                [IO.Compression.ZipFileExte"
"nsions]::CreateEntryFromFile($archive, $file,\n                    [IO.Path]::GetFileName($file), [IO.Compression.CompressionLevel]::Optimal) | Out-Null\n            }\n        } finally { $archi"
"ve.Dispose() }\n    } finally { $stream.Dispose() }\n    # Read every archived byte and compare SHA256 before publishing the final ZIP.\n    $archive = [IO.Compression.ZipFile]::OpenRead($partial"
")\n    try {\n        if ($archive.Entries.Count -ne $files.Count) { throw 'Archive entry count mismatch.' }\n        foreach ($file in $files) {\n            $entry = $archive.GetEntry([IO.Path]:"
":GetFileName($file))\n            if ($null -eq $entry -or $entry.Length -ne (Get-Item -LiteralPath $file).Length) {\n                throw 'Archive entry length mismatch.'\n            }\n       "
"     $sha = [Security.Cryptography.SHA256]::Create()\n            $original = [IO.File]::OpenRead($file)\n            try { $expected = [Convert]::ToBase64String($sha.ComputeHash($original)) }\n "
"           finally { $original.Dispose() }\n            $packed = $entry.Open()\n            try { $actual = [Convert]::ToBase64String($sha.ComputeHash($packed)) }\n            finally { $packed."
"Dispose(); $sha.Dispose() }\n            if ($expected -ne $actual) { throw 'Archive entry hash mismatch.' }\n        }\n    } finally { $archive.Dispose() }\n    if ([IO.File]::Exists($cancelPath"
")) { throw 'Diagnostic export cancelled or timed out.' }\n    [IO.File]::Move($partial, $zipPath)\n    $published = $true\n    # Remove only the known files after publication. No recursive deleti"
"on.\n    foreach ($file in $files) { [IO.File]::Delete($file) }\n    [IO.Directory]::Delete($stage, $false)\n    Complete-ELDiagnostic 'OK'\n    exit 0\n} catch {\n    # A completed verified ZIP is "
"still successful if snapshot cleanup was blocked.\n    if ($published) { Complete-ELDiagnostic 'OK'; exit 0 }\n    try {\n        if ($statusPath -and [IO.Directory]::Exists($stage)) {\n          "
"  [IO.File]::WriteAllText([IO.Path]::Combine($stage, 'bundle-error.txt'),\n                $_.Exception.ToString(), (New-Object Text.UTF8Encoding($false)))\n        }\n    } finally {\n        if "
"($statusPath -and -not [IO.File]::Exists($statusPath)) { Complete-ELDiagnostic 'ERROR' }\n    }\n    exit 1\n}\n"
)))

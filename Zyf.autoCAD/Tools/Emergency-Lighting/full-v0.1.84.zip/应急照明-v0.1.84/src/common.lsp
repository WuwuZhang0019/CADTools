;; AutoCAD 2020 trial, GB2312 source and system-codepage data. Pure functions shared by CAD and host checks.
(defun EL:Get (key data) (cdr (assoc key data)))
(defun EL:Put (key value data / old)
  (if (setq old (assoc key data))
    (subst (cons key value) old data)
    (append data (list (cons key value)))))
;; Date: 2026-10-22. Only Tianzheng's numbered equipment names have a computer suffix.
;; Input is already upper-case; raw names, definition geometry and saved keys stay intact.
(defun EL:TianzhengNameCore (key / prefix mark openmark closemark offset core)
  (if (equal (type key) 'STR)
    (setq prefix (cond ((equal (substr key 1 9) "$EQUIP_U$") 9)
      ((equal (substr key 1 7) "$EQUIP$") 7))))
  (if prefix
    (progn
      (setq core key mark (cond ((vl-string-search "(" key) (list "(" ")"))
        ((vl-string-search "��" key) (list "��" "��"))))
      (if mark
        (progn
          (setq openmark (car mark) closemark (cadr mark) offset (vl-string-search openmark key))
          (setq core (if (and (> offset prefix)
            (> (- (strlen key) (strlen closemark)) (+ offset (strlen openmark)))
            (not (vl-string-search openmark key (+ offset (strlen openmark))))
            (equal (vl-string-search closemark key (+ offset (strlen openmark))) (- (strlen key) (strlen closemark))))
            (substr key 1 offset)))))
      (if (and core (> (strlen core) prefix)
        (vl-every '(lambda (c) (and (>= c 48) (<= c 57))) (vl-string->list (substr core (1+ prefix))))) core))))
(defun EL:TianzhengNameKey (name)
  (if (and (equal (type name) 'STR) (equal (substr name 1 1) "$"))
    (EL:TianzhengNameCore (strcase name))))
(defun EL:BlockNameMatchKey (name / key)
  (if (equal (type name) 'STR)
    (progn (setq key (strcase name)) (cond ((EL:TianzhengNameCore key)) (T key)))))
(defun EL:Unique (items / out item)
  (foreach item items (if (not (member item out)) (setq out (cons item out))))
  (reverse out))
(defun EL:Issue (code object detail)
  (list (cons 'code code) (cons 'object object) (cons 'detail detail)))
(defun EL:Number (x) (and (numberp x) (= x x) (< (abs x) 1.0e100)))
(defun EL:NonNegative (x) (and (EL:Number x) (>= x 0)))
(defun EL:Point (p)
  (and (listp p) (= (length p) 3)
       (EL:Number (car p)) (EL:Number (cadr p)) (EL:Number (caddr p))))
(defun EL:Point3 (p) (list (car p) (cadr p) (cond ((caddr p)) (T 0.0))))
(defun EL:V+ (a b) (mapcar '+ a b))
(defun EL:V- (a b) (mapcar '- a b))
(defun EL:V* (s a) (mapcar '(lambda (v) (* s v)) a))
(defun EL:Dot (a b) (apply '+ (mapcar '* a b)))
(defun EL:Cross (a b) (- (* (car a) (cadr b)) (* (cadr a) (car b))))
(defun EL:Norm (v) (sqrt (EL:Dot v v)))
(defun EL:Unit (v / n)
  (if (> (setq n (EL:Norm v)) 1.0e-9) (EL:V* (/ 1.0 n) v)))
(defun EL:Last (xs) (car (reverse xs)))
(defun EL:Strings (xs / ok x)
  (setq ok (listp xs))
  (foreach x xs (if (not (equal (type x) 'STR)) (setq ok nil))) ok)
(defun EL:ParamsValid (p / ok key)
  (setq ok T)
  (foreach key '(eps_touch eps_boundary eps_perp eps_z theta_max R0 Dmax)
    (if (not (EL:NonNegative (EL:Get key p))) (setq ok nil)))
  (and ok (or (not (assoc 'eps_device p)) (EL:NonNegative (EL:Get 'eps_device p)))
       (< (EL:Get 'theta_max p) (/ pi 2.0))
       (> (EL:Get 'R0 p) 0) (<= (EL:Get 'R0 p) (EL:Get 'Dmax p))
       (> (EL:Get 'Dmax p) (EL:Get 'eps_touch p))))
(defun EL:LayerAllowed (a b config)
  (and (member a (EL:Get 'wire-layers config))
       (member b (EL:Get 'wire-layers config))
       (or (equal a b) (member (list a b) (EL:Get 'layer-pairs config))
           (member (list b a) (EL:Get 'layer-pairs config)))))
(defun EL:Hash (s / h n)
  (setq h 5381)
  (foreach n (vl-string->list s) (setq h (rem (+ (* h 33.0) n) 2147483629.0)))
  (rtos h 2 0))
(defun EL:StableData (data / tail items result item)
  ;; Date: 2026-10-09. Iterate list tails: stack depth follows nesting, not entity count.
  (cond ((equal (type data) 'ENAME) (list 'handle (cdr (assoc 5 (entget data)))))
        ;; Date: 2026-10-15. Native list traversal avoids rebuilding every
        ;; proper-list tail twice. Dotted tails retain the exact legacy path.
        ((and (listp data) (vl-list-length data))
          (mapcar '(lambda (item) (if (member (type item) '(LIST ENAME))
            (EL:StableData item) item)) data))
        ((listp data)
          (setq tail data)
          (while (and tail (listp tail))
            ;; Date: 2026-10-15. Atomic values already have their exact stable
            ;; representation. Recurse only for nested lists and entity names.
            (setq item (car tail)
              items (cons (if (member (type item) '(LIST ENAME))
                (EL:StableData item) item) items) tail (cdr tail)))
          (setq result (if (equal (type tail) 'ENAME) (EL:StableData tail) tail))
          (foreach item items (setq result (cons item result))) result)
        (T data)))
(defun EL:Signature (data) (vl-prin1-to-string (EL:StableData data)))
(defun EL:StableSnapshot (snapshot / owner epoch)
  ;; Date: 2026-10-15. Builders retain immutable alist rows. Convert each
  ;; identical row once inside this synchronous recognition pass, including
  ;; unknown fields. Changed rows, writes, interaction and DWG changes miss.
  (if (and *EL:RecognitionPass* (vl-list-length snapshot))
    (progn
      (setq owner (namedobjdict) epoch *EL:FreshEpoch*)
      (if (not (and (equal owner *EL:StableSnapshotOwner*) (equal epoch *EL:StableSnapshotEpoch*)))
        (setq *EL:StableSnapshotMemo* nil *EL:StableSnapshotOwner* owner *EL:StableSnapshotEpoch* epoch))
      (mapcar 'EL:StableSnapshotRow snapshot))
    (EL:StableData snapshot)))
(defun EL:StableSnapshotRow (row / saved value)
  (if (setq saved (vl-some '(lambda (item) (if (eq row (car item)) item)) *EL:StableSnapshotMemo*))
    (cadr saved)
    (progn
      (setq value (EL:StableData row)
        *EL:StableSnapshotMemo* (cons (list row value) *EL:StableSnapshotMemo*)) value)))
(defun EL:RecognitionRules (cfg / rows key)
  (foreach key '(wire-styles auto-panel concentrated-trunk circuit-starts wire-layers panel-layers device-layers leader-layers panel-names device-names leader-names
      layer-pairs params calibrated gap-pairs leader-pairs roles exits)
    (setq rows (cons (cons key (EL:Get key cfg)) rows)))
  ;; Date: 2026-10-13. Older recognition must be rebuilt for exact reachable traversal.
  (cons '(block-name-match-policy . 1) (cons '(reachable-contact-policy . 2) (cons '(junction-policy . 1) (cons '(number-branch-policy . 1)
    (cons '(simple-gap-policy . 1) (cons '(box-policy . 20) (cons '(gap-policy . 10) (reverse rows)))))))))
;; Date: 2026-10-11. Report which freshness condition failed.
(defun EL:SourceSignatureCore (signature)
  (if (and (listp signature) (equal (car signature) 'EL_FIXED_SOURCE_V1))
    (list 'EL_FIXED_SOURCE_V1 (vl-remove-if '(lambda (row) (equal (car row) 'network-proof)) (cadr signature)))
    signature))
(defun EL:SourceCurrent (result cfg fresh / drawing rules snapshot)
  (setq drawing (equal (EL:Get 'drawing result) (EL:Get 'drawing cfg))
    rules (equal (EL:Get 'rules result) (EL:RecognitionRules cfg))
    snapshot (equal (EL:SourceSignatureCore (EL:Get 'signature fresh))
      (EL:SourceSignatureCore (EL:Get 'signature (EL:Get 'snapshot result)))))
  (if (not (and drawing rules snapshot))
    (EL:LogEvent "SOURCE_COMPARE_FAILED" (list (cons 'drawing-equal drawing)
      (cons 'rules-equal rules) (cons 'snapshot-equal snapshot))))
  (if (not snapshot) (EL:LogSnapshotDifference (EL:Get 'snapshot result) fresh))
  (and drawing rules snapshot))
(defun EL:OptionLabel (option)
  (cond ((equal option 'cap300) "0.3kW") ((equal option 'cap600) "0.6kW") ((equal option 'cap1000) "1kW")
        ((equal option 'normal) "��ͨ") ((equal option 'ground) "����") ((equal option 'reserve) "Ԥ��") (T "δѡ��")))
(defun EL:OnlyKeys (data keys / ok row seen)
  (setq ok (listp data))
  (foreach row data
    (if (or (not (listp row)) (not (member (car row) keys)) (member (car row) seen))
      (setq ok nil))
    (setq seen (cons (car row) seen))) ok)
(princ)

(defun EL:Tick (/ value)
  (setq value (vl-catch-all-apply 'getvar (list "MILLISECS")))
  (if (numberp value) value 0))
(defun EL:Elapsed (start) (max 0 (- (EL:Tick) start)))

;; Date: 2026-10-11. Command-scoped P0 counters, independent of business logs.
;; Inclusive stages overlap; user intervals are a union and are never summed twice.
(defun EL:PerfDelta (start stop)
  (if (< stop start) (+ (- stop start) 4294967296.0) (- stop start)))
(defun EL:PerfSet (key value)
  (if *EL:PerfActive* (setq *EL:PerfMetrics* (EL:Put key value *EL:PerfMetrics*))) nil)
(defun EL:PerfCount (key amount)
  (if *EL:PerfActive*
    (EL:PerfSet key (+ (cond ((EL:Get key *EL:PerfMetrics*)) (T 0)) amount))) nil)
(defun EL:PerfWaiting (/ elapsed)
  (setq elapsed *EL:PerfWaitMS*)
  (if (> *EL:PerfWaitDepth* 0)
    (setq elapsed (+ elapsed (EL:PerfDelta *EL:PerfWaitStart* (EL:Tick))))) elapsed)
;; Date: 2026-10-21. Session-only 2x2 recognition comparison; no drawing writes.
;; 0 optimized, 1 detailed reads, 2 old single-candidate bounds, 3 both old paths.
(defun EL:PerformanceCompareMode (/ mode)
  (setq mode (if (and *EL:PerfActive* (equal (type *EL:PerfCompareRunMode*) 'INT)
      (>= *EL:PerfCompareRunMode* 0) (<= *EL:PerfCompareRunMode* 3))
    *EL:PerfCompareRunMode* *EL:PerfCompareMode*))
  (if (and (equal (type mode) 'INT) (>= mode 0) (<= mode 3)) mode 0))
(defun EL:CollectReadDetailEnabled () (if (member (EL:PerformanceCompareMode) '(1 3)) T nil))
(defun EL:NumberSingleBoundsEnabled () (if (member (EL:PerformanceCompareMode) '(2 3)) T nil))
(defun EL:PerformanceCompareLabel (mode)
  (cond ((= mode 1) "������ʵ��ϸ�ּ�ʱ") ((= mode 2) "�������ɵ���ѡ��ɸ")
    ((= mode 3) "ʵ��ϸ�ּ�ʱ���ɵ���ѡ��ɸ") (T "�Ż�Ĭ�ϣ����μ�ʱ������ѡֱ�Ӿ���")))
(defun EL:PerfStart (commandname / stamp tick key comparemode)
  (if (not *EL:PerfActive*)
    (progn
      (setq comparemode (EL:PerformanceCompareMode)
        tick (vl-catch-all-apply 'getvar (list "MILLISECS")))
      (setq *EL:PerfCompareRunMode* comparemode *EL:PerfActive* T *EL:PerfCommand* commandname *EL:PerfStarted* (if (numberp tick) tick 0)
        *EL:DiagnosticsDeferred* nil *EL:DeferredLogEvents* nil
        *EL:PerfMetrics* nil *EL:PerfStages* nil *EL:PerfPending* nil *EL:PerfMarks* nil *EL:StoreReadCache* nil *EL:NetworkMemo* nil *EL:CollectMemo* nil *EL:StatisticsMemo* nil *EL:SplitCache* nil *EL:DLCache* nil *EL:DLSessionSnapshot* nil
        *EL:PerfWaitMS* 0 *EL:PerfWaitDepth* 0 *EL:PerfSerial* 0 *EL:PerfOutcome* nil
        *EL:StoreReadScope* (1+ (cond (*EL:StoreReadScope*) (T 0))))
      (setq stamp (vl-catch-all-apply 'getvar (list "CDATE")))
      (setq *EL:MonitorRows* nil *EL:MonitorError* nil *EL:MonitorUIStack* nil
        *EL:MonitorStamp* (if (numberp stamp) (rtos stamp 2 6) "unavailable"))
      ;; Date: 2026-10-21. Association evidence must identify the exact run,
      ;; including two commands that start within the same CDATE second.
      (setq *EL:PerfRunSequence* (1+ (cond (*EL:PerfRunSequence*) (T 0)))
        *EL:PerfRunID* (list *EL:MonitorStamp* *EL:PerfStarted* *EL:PerfRunSequence*))
      (EL:PerfSet "date" (if (numberp stamp) stamp "unavailable"))
      (EL:PerfSet "clock-available" (if (numberp tick) T nil))
      (foreach key '("recognize-fixed-calls" "store-read-calls" "store-write-calls"
          "entity-write-attempts" "entity-write-returned" "master-write-attempts"
          "block-create-attempts" "text-create-attempts" "transaction-starts"
          "transaction-failures" "log-open-attempts" "log-write-attempts" "log-close-attempts" "panel-submits"
          "store-read-cache-hits" "store-read-cache-misses"
          "start-snapshot-source-wires" "start-snapshot-kept-wires" "start-snapshot-removed-wires" "start-snapshot-ends"
          "start-boundary-pair-checks" "start-boundary-bounds-rejected" "start-boundary-exact-checks" "start-boundary-bounds-fallback-wires"
          "source-collect-calls" "source-selection-entities" "source-block-bounds-reads"
          "source-selection-inserts" "source-selection-lines" "source-selection-polylines" "source-selection-other"
          "source-selection-managed-outputs" "source-rejected-block-inserts" "source-candidate-blocks"
          "recognized-connected-wires" "recognized-connected-devices"
          "root-scope-light-wires" "root-scope-fine-wires" "root-scope-skipped-wires"
          "root-scope-wire-materializations" "root-scope-wire-fallbacks" "root-scope-order-wire-reads"
          "root-scope-proxy-wires" "root-scope-all-fallback-bypass"
          "source-native-entity-checks" "source-native-bounds-checks" "source-derived-reuses"
          "source-candidate-index-lookups" "source-candidate-index-steps" "source-candidate-index-duplicates"
          ;; Date: 2026-10-21. Publish one aggregate per synchronous batch.
          "source-wire-layer-reads" "source-wire-layer-cache-hits" "source-wire-layer-read-ms"
          "source-native-dxf-ms" "source-block-bounds-ms" "source-wire-record-ms" "source-read-profile-clock-reads"
          "source-read-profile-enabled"
          "source-preset-cache-hits" "source-preset-cache-misses" "source-preset-normalizations"
          "source-preset-table-cache-hits" "source-preset-table-cache-misses"
          "source-preset-cache-rebuilds" "source-preset-cache-miss-check-ms"
          "preview-source-ids" "preview-source-color-reads" "preview-source-rgb-duplicates" "preview-source-rgb-unique"
          "preview-layer-color-reads" "preview-layer-color-cache-hits"
          "network-role-blocks" "network-role-ordered-batches" "network-role-fallback-batches"
          "source-wire-record-reads" "device-contour-reads" "device-template-reuses"
          ;; Date: 2026-10-21. Definitions, complete poses and numeric fallbacks differ.
          "device-definition-reuses" "device-pose-builds" "device-pose-reuses" "device-pose-fallbacks"
          "device-definition-check-ms" "device-pose-verify-ms" "device-definition-build-ms"
          "device-instance-build-ms" "device-regions-build-ms" "device-contact-prepare-ms"
          "template-sample-find-ms" "template-sample-scans"
          "template-definition-check-ms" "template-definition-builds" "template-definition-reuses"
          "template-dynamic-check-ms" "template-dynamic-checks" "template-dynamic-reuses"
          "template-probe-ms" "template-probes" "template-probe-reuses"
          "network-build-calls" "network-verified-reuses" "network-geometry-checks"
          "number-prefix-searches" "number-prefix-bounds-builds" "number-prefix-bounds-tests"
          "number-prefix-bounds-rejected" "number-prefix-exact-tests" "number-prefix-bounds-fallbacks"
          "number-prefix-single-bypasses" "number-prefix-single-searches"
          "number-prefix-full-segment-builds" "number-prefix-full-segment-reuses"
          "number-prefix-strip-builds" "number-prefix-strip-reuses"
          "number-prefix-wide-builds" "number-prefix-wide-reuses"
          "number-scope-visits" "number-scope-neighbour-scans" "number-scope-path-lengths"
          "number-scope-neighbours-ms" "number-scope-first-device-ms" "number-scope-links-ms"
          "number-annotation-scans" "number-annotation-reads" "number-annotation-orphans"
          "number-annotation-scan-failures" "number-annotation-linked-reads"
          "number-scopes" "number-source-handles" "number-problems"
          "number-source-read-attempts" "number-source-read-failures" "number-freshness-checks"
          "device-library-loads" "device-library-writes" "device-library-matches" "device-library-unknown"
          "device-legend-loads" "device-legend-builds")
        (EL:PerfSet key 0))
      (EL:PerfSet "recognition-compare-mode" comparemode)
      (EL:PerfSet "number-prefix-single-baseline" (if (EL:NumberSingleBoundsEnabled) 1 0)) T)))
(defun EL:PerfBegin (stage / token wait parent paused)
  (if *EL:PerfActive*
    (progn
      ;; Date: 2026-10-13. DCL callbacks do work inside start_dialog.
      ;; Pause its input clock until the callback returns, including error unwind.
      ;; Date: 2026-10-20. Native input can re-enter a command before its outer
      ;; input frame returns. Any measured program work must suspend that wait.
      (if (and (not (member stage '("USER_INPUT" "PLACEMENT_INPUT"))) (> *EL:PerfWaitDepth* 0))
        (setq paused *EL:PerfWaitDepth*
          *EL:PerfWaitMS* (EL:PerfWaiting) *EL:PerfWaitDepth* 0))
      (setq wait (member stage '("USER_INPUT" "PLACEMENT_INPUT"))
        parent (if *EL:PerfPending* (EL:Get 'stage (car *EL:PerfPending*)))
        *EL:PerfSerial* (1+ *EL:PerfSerial*)
        token (list (cons 'id *EL:PerfSerial*) (cons 'stage stage) (cons 'start (EL:Tick))
          (cons 'wait-before (EL:PerfWaiting)) (cons 'interactive (if wait T nil)) (cons 'parent parent)
          (cons 'parent-id (if *EL:PerfPending* (EL:Get 'id (car *EL:PerfPending*)) 0))
          (cons 'label *EL:MonitorLabel*) (cons 'resume-wait paused)))
      (if wait
        (progn
          (if (= *EL:PerfWaitDepth* 0) (setq *EL:PerfWaitStart* (EL:Get 'start token)))
          (setq *EL:PerfWaitDepth* (1+ *EL:PerfWaitDepth*))))
      (setq *EL:PerfPending* (cons token *EL:PerfPending*)) token)))
(defun EL:PerfEnd (token status / stage row elapsed waited key parents)
  (if (and *EL:PerfActive* token (member token *EL:PerfPending*))
    (progn
      (if (EL:Get 'interactive token)
        (progn
          (setq *EL:PerfWaitDepth* (1- *EL:PerfWaitDepth*))
          (if (= *EL:PerfWaitDepth* 0)
            (setq *EL:PerfWaitMS* (+ *EL:PerfWaitMS* (EL:PerfDelta *EL:PerfWaitStart* (EL:Tick)))))))
      (setq stage (EL:Get 'stage token) row (EL:Get stage *EL:PerfStages*)
        elapsed (EL:PerfDelta (EL:Get 'start token) (EL:Tick))
        waited (max 0 (- (EL:PerfWaiting) (EL:Get 'wait-before token))))
      (foreach key (list (cons 'calls 1) (cons 'inclusive-ms elapsed)
          (cons 'program-ms (max 0 (- elapsed waited))) (cons 'interrupted (if (equal status 'returned) 0 1)))
        (setq row (EL:Put (car key) (+ (cond ((EL:Get (car key) row)) (T 0)) (cdr key)) row)))
      (setq parents (EL:Get 'parents row))
      (if (and (EL:Get 'parent token) (not (member (EL:Get 'parent token) parents)))
        (setq row (EL:Put 'parents (cons (EL:Get 'parent token) parents) row)))
      (setq *EL:PerfStages* (EL:Put stage row *EL:PerfStages*)
        *EL:MonitorRows* (cons (append token (list (cons 'elapsed-ms elapsed)
          (cons 'program-ms (max 0 (- elapsed waited))) (cons 'status status))) *EL:MonitorRows*)
        *EL:PerfPending* (vl-remove token *EL:PerfPending*))
      (if (EL:Get 'resume-wait token)
        (setq *EL:PerfWaitDepth* (EL:Get 'resume-wait token) *EL:PerfWaitStart* (EL:Tick))))) nil)
(defun EL:PerfUnwind (checkpoint)
  (while (and *EL:PerfPending* (not (equal checkpoint *EL:PerfPending*)))
    (EL:PerfEnd (car *EL:PerfPending*) 'interrupted)) nil)
(defun EL:FreshBoundary ()
  ;; Date: 2026-10-11. Input, native commands, writes and unknown callbacks
  ;; invalidate the current operation's sampled source; never cache a command.
  (setq *EL:FreshProofContext* nil *EL:FreshEpoch* (1+ (cond (*EL:FreshEpoch*) (T 0)))) nil)
(defun EL:PerfCall (stage function arguments / token result *EL:MonitorLabel*)
  (if (member stage '("USER_INPUT" "PLACEMENT_INPUT" "PANEL_DIALOG")) (EL:FreshBoundary))
  (if (and *EL:PerfActive* (or (member stage
      '("USER_INPUT" "PLACEMENT_INPUT" "PANEL_DIALOG" "RECOGNIZE_FIXED_RUN" "LOAD_ROOT" "LOAD_LIBRARY" "PICK_PANEL" "PICK_TRUNK"
        ;; Date: 2026-10-22. Cold-probe batches must be recorded without detail mode.
        "COLD_NATIVE_LOAD" "COLD_NATIVE_PROBE"
        "LOAD_ROOT_SEARCH" "LOAD_RUNTIME" "LOAD_RUNTIME_TEXT" "LOAD_RUNTIME_ASSETS"
        "PANEL_START_LOAD" "PANEL_START_NEW" "PANEL_START_INIT" "PANEL_START_BUTTONS" "PANEL_START_WAIT"
        "PANEL_HISTORY_READ" "PANEL_HISTORY_RESTORE" "PANEL_FILL" "PREPARE_PANEL" "NEW_RECORD" "READ_STORE"
        "RECOGNIZE_FIXED" "RECOGNIZE_TRUNK" "SAVE_GENERATION_DRAFT" "STORE_REPLACE_PAYLOAD"
        "UNDO_BEGIN" "UNDO_END" "TX_MARKER_CREATE" "RECOVERY_UNDO_END"
        "SIMPLE_COLLECT" "SIMPLE_NETWORK" "SOURCE_NATIVE_VERIFY" "NETWORK_VERIFY_GEOMETRY" "NETWORK_BUILD" "SPLIT_NETWORK" "CIRCUIT_NUMBER_SCOPE"
        "COMPARE_SOURCE_NUMBER" "PRE_GENERATE_FRESH" "FRESH_SOURCE_SCAN"
        "CCKK2" "CCKK2_CREATE" "SAVE_CREATED_DIAGRAM" "COMPONENT_INDEX" "STORE_CURRENT_BOX"
        "TX_WRITE" "STORE_READ" "STORE_DECODE" "STORE_CACHE_CHECK" "STORE_SERIALIZE"
        "STORE_PARSE" "STORE_READBACK" "STORE_CONTEXT_COMMIT" "STORE_CONTEXT_READ"
        "STORE_MIGRATE_BACKUP" "STORE_STAGE_BUILD"
        "STORE_COMPACT" "STORE_PACK_INTS" "STORE_NATIVE_ENCODE" "STORE_NATIVE_DECODE" "STORE_EXPAND"
        "STORE_UNPACK_INTS" "STORE_VALUE_DECODE"
        "DIAGRAM_VIEW" "DIAGNOSTIC_EXPORT" "DEVICE_LIBRARY_LOAD" "DEVICE_LEGEND"
        "SYSTEM_LIBRARY_OPEN" "SYSTEM_BLOCK_COPY" "SYSTEM_STYLE_COPY" "TEMPLATE_CAPTURE" "TEMPLATE_VALIDATE"
        ;; Date: 2026-10-21. Recognition batches, never per-entity/probe frames.
        "START_SNAPSHOT" "START_BOUNDARY_FILTER" "START_ENDS_BUILD" "COLLECT_PRESET_PREPARE" "NUMBER_ANNOTATION_INDEX"
        "NETWORK_ROLE_PREPARE" "NETWORK_WIRE_INDEX" "NETWORK_BLOCK_INDEX" "NETWORK_JUNCTION_INDEX"
        "NETWORK_END_INDEX" "NETWORK_GAP_INDEX" "NETWORK_ROOT_LINKS"
        "COLLECT_SPATIAL_TREE" "COLLECT_CANDIDATE_DEDUP" "COLLECT_DEVICE_EXPAND"
        "PANEL_SELECT_EXITS" "PANEL_COMPUTE" "PANEL_PREVIEW_PALETTE" "PREVIEW_SOURCE_COLORS" "PREVIEW_PALETTE_FILTER"
        "NETWORK_PROOF_PREPARE" "NETWORK_PROOF_STABLE_INPUT" "NETWORK_PROOF_STABLE_OUTPUT"
        "NETWORK_PROOF_CONTACTS" "NETWORK_ROLE_RESTORE" "NETWORK_PROOF_COMPARE"
        "PANEL_SUBMIT_PREPARE" "GENERATION_CONTEXT" "GENERATION_PREPARE" "GENERATION_SOURCE_VERIFY"
        "GENERATION_PLAN" "GENERATION_RECORD" "PLACEMENT_PLAN_REBUILD"
        "NATIVE_INSERT" "PANEL_DYNAMIC_SET" "CIRCUIT_DYNAMIC_SET"
        "PLACEMENT_TEMPLATE_VERIFY" "PLACEMENT_NUMBER_VERIFY" "PLACEMENT_LIBRARY_VERIFY" "PLACEMENT_SOURCE_VERIFY"
        "CREATE_CIRCUITS" "CREATE_POWER_TEXT" "CREATE_CAPTIONS" "DIAGRAM_FINALIZE" "TX_MARKER_CLEANUP" "TX_COMMIT"))
      (and *EL:PerfDetail* (member stage
        '("STORE_SCHEMA" "STORE_REPLACE_PAYLOAD" "CCKK2_INSERT_BLOCK" "CCKK_POWER_TEXT"
          "TAG_ENTITY" "UNDO_BEGIN" "UNDO_END" "COMPARE_SOURCE" "SNAPSHOT_SIGNATURE" "CIRCUIT_TRACE")))))
    (progn
      (setq *EL:MonitorLabel* (if (equal (type function) 'SYM) (vl-symbol-name function) stage))
      (if (and (equal stage "USER_INPUT") (equal (type (car arguments)) 'STR))
        (setq *EL:MonitorLabel* (strcat *EL:MonitorLabel* " " (car arguments))))
      (setq token (EL:PerfBegin stage))))
  ;; Keep native return values and exceptions. Caught transactions unwind their frames.
  (setq result (apply function arguments))
  ;; A callback may sample the source and then change it during this input.
  ;; That sample cannot survive the return to the enclosing operation.
  (if (member stage '("USER_INPUT" "PLACEMENT_INPUT" "PANEL_DIALOG")) (EL:FreshBoundary))
  (EL:PerfEnd token 'returned)
  (if (and result (equal stage "PLACEMENT_INPUT")) (EL:PerfMark "placement-confirmed")) result)
(defun EL:PerfInput (function arguments)
  (EL:PerfCall "USER_INPUT" function arguments))
(defun EL:PerfWrite (function arguments / result)
  ;; Attempts count the actual interface invocation, including nil/error returns.
  (EL:FreshBoundary)
  (EL:PerfCount "entity-write-attempts" 1)
  (if *EL:PerfDetail* (EL:PerfCount (strcat "write/" (vl-symbol-name function)) 1))
  (setq result (apply function arguments))
  (EL:FreshBoundary)
  (EL:PerfCount "entity-write-returned" 1) result)
(defun EL:PerfMark (key)
  (if *EL:PerfActive*
    (setq *EL:PerfMarks* (EL:Put key (list (EL:Tick) (EL:PerfWaiting)) *EL:PerfMarks*))) nil)
(defun EL:PerfMarkDuration (key / mark elapsed)
  (if (setq mark (EL:Get key *EL:PerfMarks*))
    (progn (setq elapsed (EL:PerfDelta (car mark) (EL:Tick)))
      (list (cons 'inclusive-ms elapsed)
        (cons 'program-ms (max 0 (- elapsed (- (EL:PerfWaiting) (cadr mark)))))))))
(defun EL:PerfAppend (path line / file result closed)
  (if (setq file (open path "a"))
    (progn
      (setq result (vl-catch-all-apply 'write-line (list line file))
        closed (vl-catch-all-apply 'close (list file)))
      (and (not (vl-catch-all-error-p result)) (not (vl-catch-all-error-p closed))))))
(defun EL:PerfReport (summary / path line written folder)
  (setq line (strcat "PERF | " (vl-prin1-to-string summary)))
  (if (and (equal (type *EL:Root*) 'STR) (/= *EL:Root* ""))
    (progn
      (vl-catch-all-apply 'vl-mkdir (list (strcat *EL:Root* "output")))
      (setq path (strcat *EL:Root* "output/ELPERF.log")
        written (vl-catch-all-apply 'EL:PerfAppend (list path line)))))
  (if (or (vl-catch-all-error-p written) (not written))
    (progn
      (setq folder (vl-catch-all-apply 'getvar (list "TEMPPREFIX")))
      (if (and (equal (type folder) 'STR) (/= folder ""))
        (setq path (strcat folder "ELPERF.log")
          written (vl-catch-all-apply 'EL:PerfAppend (list path line))))))
  (princ (strcat "\n���ܻ��ܣ������� " (itoa (fix (EL:Get 'total-ms summary)))
    " ms���������� " (itoa (fix (EL:Get 'interaction-ms summary)))
    " ms���������� " (itoa (fix (EL:Get 'program-ms summary))) " ms��"))
  (if (and (not (vl-catch-all-error-p written)) written)
    (princ (strcat "\n���ܼ�¼��" path))
    (princ "\n���ܼ�¼д��ʧ�ܣ����ܱ����� *EL:PerfLastSummary*��")) nil)
(defun EL:PerfBusinessOutcome (status)
  ;; Date: 2026-10-21. Native completion is not a successful recognition.
  (cond
    ((equal status 'failed) (if (equal *EL:PerfOutcome* 'cancelled) 'cancelled 'failed))
    ((member status '(cancelled interrupted-by-load load-failed)) status)
    (*EL:PerfOutcome*) (T 'not-recorded)))
(defun EL:PerfFinish (status / elapsed waited summary outcome)
  (if *EL:PerfActive*
    (progn
      (EL:PerfUnwind nil)
      (setq elapsed (EL:PerfDelta *EL:PerfStarted* (EL:Tick)) waited (EL:PerfWaiting)
        outcome (EL:PerfBusinessOutcome status)
        summary (list '(schema . 2) (cons 'run-id *EL:PerfRunID*)
          (cons 'command *EL:PerfCommand*) (cons 'status status) (cons 'command-status status)
          (cons 'business-outcome outcome) (cons 'last-outcome outcome) (cons 'package *EL:PackageMarker*)
          (cons 'detail (if *EL:PerfDetail* T nil)) (cons 'business-logs (if *EL:PerfLogsOff* 'off 'on))
          (cons 'total-ms elapsed) (cons 'interaction-ms waited) (cons 'program-ms (max 0 (- elapsed waited)))
          (cons 'after-submit (EL:PerfMarkDuration "panel-submit"))
          (cons 'after-placement (EL:PerfMarkDuration "placement-confirmed"))
          (cons 'after-graphics (EL:PerfMarkDuration "graphics-complete"))
          (cons 'metrics *EL:PerfMetrics*) (cons 'stages *EL:PerfStages*)))
      ;; Snapshot before reporting: summary I/O is outside all business measurements.
      (setq *EL:PerfLastSummary* summary *EL:PerfActive* nil *EL:PerfCompareRunMode* nil *EL:PerfPending* nil
        *EL:PerfMetrics* nil *EL:PerfStages* nil *EL:PerfMarks* nil *EL:PerfLogOwner* nil *EL:StoreReadCache* nil)
      (if *EL:DiagnosticsDeferred*
        ;; Date: 2026-10-15. Do not format or write diagnostics on the exit
        ;; path. Keep one completed run per open drawing for the export button.
        (if (or *EL:MonitorError* (EL:Get 'after-submit summary)
            ;; Date: 2026-10-22. Silent native DCL failures must replace an old export context.
            (EL:Get "panel-not-shown-reason" (EL:Get 'metrics summary))
            (> (cond ((EL:Get "recognize-fixed-calls" (EL:Get 'metrics summary))) (T 0)) 0)
            (not (EL:Get (namedobjdict) *EL:DiagnosticRuns*)))
          (setq *EL:DiagnosticRuns* (EL:Put (namedobjdict)
          (list (cons 'summary summary) (cons 'rows *EL:MonitorRows*)
            (cons 'origin *EL:PerfStarted*) (cons 'stamp *EL:MonitorStamp*)
            (cons 'error *EL:MonitorError*) (cons 'events *EL:DeferredLogEvents*)
            (cons 'load-summary *EL:MonitorLoadSummary*) (cons 'load-rows *EL:MonitorLoadRows*)
            (cons 'load-origin *EL:MonitorLoadOrigin*) (cons 'load-stamp *EL:MonitorLoadStamp*))
          *EL:DiagnosticRuns*)))
        (progn
          (vl-catch-all-apply 'EL:PerfReport (list summary))
          (EL:MonitorReport summary)))))
  (setq *EL:StoreReadCache* nil *EL:NetworkMemo* nil *EL:CollectMemo* nil *EL:StatisticsMemo* nil *EL:SplitCache* nil *EL:DLCache* nil *EL:DLSessionSnapshot* nil) nil)
(defun c:ELPERF (/ option)
  (if *EL:PerfActive* (princ "\n�������ǰͳ�ƻ����ɺ��ٵ������ܲ�����")
    (progn
      (princ (strcat "\n���ܲ�����" (if *EL:PerfDetail* "ϸ��" "����")
        "��ҵ����־��" (if *EL:PerfLogsOff* "�رգ������ղ�����" "����")))
      (initget "LogsOn LogsOff Detail Summary")
      (setq option (getkword "\n[LogsOn������־/LogsOff�ر���־����/Detailϸ�ּ���/Summary���ܼ���] <����>��"))
      (cond ((equal option "LogsOn") (setq *EL:PerfLogsOff* nil))
        ((equal option "LogsOff") (setq *EL:PerfLogsOff* T))
        ((equal option "Detail") (setq *EL:PerfDetail* T))
        ((equal option "Summary") (setq *EL:PerfDetail* nil)))
      (princ "\n��Ӱ�챾�μ��ػỰ�Ĳ�����ELPERF.log ������������־���ս�������ָ� LogsOn��"))) (princ))

;; Date: 2026-10-21. Explicit diagnostic switch; Enter/cancel keep the old choice.
(defun c:ELPERFAB (/ mode)
  (if *EL:PerfActive* (princ "\n�������ǰͳ�ƻ����ɺ��ٵ���ʶ�����ģʽ��")
    (progn
      (setq mode (EL:PerformanceCompareMode))
      (princ (strcat "\n��ǰʶ�����ģʽ " (itoa mode) "��" (EL:PerformanceCompareLabel mode)))
      (setq mode (getint "\n����ģʽ [0�Ż�Ĭ��/1ʵ��ϸ�ּ�ʱ/2�ɵ���ѡ��ɸ/3����ɷ�ʽ] <����>��"))
      (if mode
        (if (and (equal (type mode) 'INT) (>= mode 0) (<= mode 3))
          (setq *EL:PerfCompareMode* mode)
          (princ "\nģʽ����Ϊ0��3��ԭѡ�񱣳ֲ��䡣")))
      (princ (strcat "\n��������ģʽ " (itoa (EL:PerformanceCompareMode)) "��"
        (EL:PerformanceCompareLabel (EL:PerformanceCompareMode))))
      (princ "\n�����λỰ��Ч������ͬͼֽ�����ö��գ�ÿ�ֽ�����ELDIAG���������ָ�ģʽ0��"))) (princ))

;; Date: 2026-10-09. Diagnostics never change recognition or propagate I/O errors.
(defun EL:LogText (value / textdata)
  (setq textdata (vl-catch-all-apply 'vl-prin1-to-string (list value)))
  (if (vl-catch-all-error-p textdata) "<unprintable>"
    (if (> (strlen textdata) 16000) (strcat (substr textdata 1 16000) " <truncated>") textdata)))
(defun EL:LogAppend (line / logfile result closed started)
  (EL:PerfCount "log-open-attempts" 1)
  (if (and *EL:PerfActive* *EL:PerfDetail*) (setq started (EL:Tick)))
  (if (setq logfile (open *EL:LogPath* "a"))
    (progn
      (EL:PerfCount "log-write-attempts" 1)
      (setq result (vl-catch-all-apply 'write-line (list line logfile)))
      (setq closed (vl-catch-all-apply 'close (list logfile)))
      (EL:PerfCount "log-close-attempts" 1)
      (if started (EL:PerfCount "log-io-ms" (EL:PerfDelta started (EL:Tick))))
      (and (not (vl-catch-all-error-p result)) (not (vl-catch-all-error-p closed))))))
;; Date: 2026-10-10. Retry in TEMP when the runtime output is unavailable.
(defun EL:LogFallback (line / folder previous result)
  (if (not *EL:LogFallbackUsed*)
    (progn
      (setq *EL:LogFallbackUsed* T previous *EL:LogPath*
        folder (vl-catch-all-apply 'getvar (list "TEMPPREFIX")))
      (if (and (equal (type folder) 'STR) (/= folder ""))
        (progn
          (setq *EL:LogPath* (strcat folder "ELTRACE-debug.log"))
          (setq result (vl-catch-all-apply 'EL:LogAppend
            (list (strcat "LOG_FALLBACK | original-path=" (EL:LogText previous)
              " | last-context=" (EL:LogText *EL:LogLast*) " | stack=" (EL:LogText *EL:LogStack*)))))
          (if (and (not (vl-catch-all-error-p result)) result)
            (setq result (vl-catch-all-apply 'EL:LogAppend (list line))))
          (and (not (vl-catch-all-error-p result)) result))))))
(defun EL:LogVisible (stage)
  (or *EL:LogVerbose* (not (member stage
    '("POLYLINE_DXF_ROW" "POLYLINE_SEGMENT" "POLYLINE_INPUT" "POLYLINE_DATA_RESULT"
      "ENTER POLYLINE_TRANS" "LEAVE POLYLINE_TRANS" "POLYLINE_TRANS_RESULT"
      "ENTER CURVE_TRANS" "LEAVE CURVE_TRANS" "CURVE_TRANS_RESULT"
      "ENTER INSERT_TRANS" "LEAVE INSERT_TRANS" "INSERT_TRANS_RESULT" "INSERT_MATRIX_INPUT"
      "ENTER SOLID_TRANS" "LEAVE SOLID_TRANS" "SOLID_TRANS_RESULT" "POLYLINE_NORMAL"
      "CONTOUR_ENTITY" "CONTOUR_FILTER_INPUT" "CONTOUR_NEXT"
      "ENTER CONTOUR_TRANSFORM" "LEAVE CONTOUR_TRANSFORM" "CONTOUR_TRANSFORM_RESULT")))))
(defun EL:LogEvent (stage context / line result started)
  (if *EL:LogActive*
    (progn
      (setq *EL:LogSequence* (1+ *EL:LogSequence*)
            *EL:LogLast* (list stage context))
      ;; Keep current failure context in memory; avoid per-vertex file I/O by default.
      (if (and (not *EL:PerfLogsOff*) *EL:DiagnosticsDeferred* (EL:LogVisible stage))
        (setq *EL:DeferredLogEvents* (cons (list *EL:LogSequence* stage context) *EL:DeferredLogEvents*)))
      (if (and (not *EL:PerfLogsOff*) (not *EL:DiagnosticsDeferred*) *EL:LogPath* (EL:LogVisible stage))
        (progn
          (if (and *EL:PerfActive* *EL:PerfDetail*) (setq started (EL:Tick)))
          (setq line (strcat (itoa *EL:LogSequence*) " | " stage " | " (EL:LogText context)))
          (if started (EL:PerfCount "log-format-ms" (EL:PerfDelta started (EL:Tick))))
          (setq result (vl-catch-all-apply 'EL:LogAppend (list line)))
          (if (or (and (not (vl-catch-all-error-p result)) result) (EL:LogFallback line)) (setq *EL:LogWritten* T)
            (setq *EL:LogIOFailed* T *EL:LogPath* nil))))))
  nil)
(defun EL:LogStart (/ stamp)
  (setq *EL:PerfLogOwner* (EL:PerfStart "ELSTAT/ELTRACE/ELPOWER"))
  (setq *EL:LogActive* T *EL:LogPath* nil *EL:LogStack* nil *EL:LogLast* nil
        *EL:LogSequence* 0 *EL:LogWritten* nil *EL:LogIOFailed* nil *EL:LogFallbackUsed* nil)
  (EL:LogAttach)
  (setq stamp (vl-catch-all-apply 'getvar (list "CDATE")))
  (EL:LogEvent "BEGIN" (list (cons 'command "ELSTAT/ELTRACE/ELPOWER") (cons 'diagnostics "031") (cons 'verbose *EL:LogVerbose*)
    (cons 'date (if (numberp stamp) stamp "unavailable")))))
(defun EL:LogAttach (/ stamp)
  (if (and *EL:LogActive* (not *EL:DiagnosticsDeferred*) (not *EL:LogPath*) (not *EL:LogIOFailed*)
           (equal (type *EL:Root*) 'STR) (/= *EL:Root* ""))
    (progn
      (vl-catch-all-apply 'vl-mkdir (list (strcat *EL:Root* "output")))
      (setq *EL:LogPath* (strcat *EL:Root* "output/ELTRACE-debug.log")
            stamp (vl-catch-all-apply 'getvar (list "CDATE")))
      (EL:LogEvent "ATTACH" (list (cons 'diagnostics "031")
        (cons 'date (if (numberp stamp) stamp "unavailable")))))))
(defun EL:LogCall (stage context function arguments / result started)
  ;; Leave the stack intact on an AutoLISP error; the command's *error* records it.
  (if *EL:LogActive*
    (progn (setq *EL:LogStack* (cons (list stage context) *EL:LogStack*))
      (EL:LogEvent (strcat "ENTER " stage) context)))
  (setq started (if *EL:LogActive* (EL:Tick)) result (EL:PerfCall stage function arguments))
  (if *EL:LogActive*
    (progn
      (EL:LogEvent (strcat "LEAVE " stage) (list (cons 'elapsed-ms (EL:Elapsed started)) (cons 'result-type (type result))))
      (setq *EL:LogStack* (cdr *EL:LogStack*))))
  result)
(defun EL:MeasuredCatch (function arguments / pending stack result)
  ;; Date: 2026-10-13. Close only the frames created inside this catch.
  (setq pending *EL:PerfPending* stack *EL:LogStack*
    result (vl-catch-all-apply function arguments))
  (if (vl-catch-all-error-p result)
    (progn
      (EL:LogEvent "CAUGHT_ERROR" (list (cons 'message (vl-catch-all-error-message result))
        (cons 'frames *EL:LogStack*)))
      (EL:PerfUnwind pending)
      (setq *EL:LogStack* stack))) result)
(defun EL:LogEntity (entity)
  (EL:LogEntityData (entget entity)))
(defun EL:LogEntityData (data)
  ;; Date: 2026-10-15. Reuse the same fresh DXF read for diagnostic context.
  (list (cons 'handle (cdr (assoc 5 data))) (cons 'type (cdr (assoc 0 data)))
    (cons 'layer (cdr (assoc 8 data))) (cons 'block (cdr (assoc 2 data)))
    (cons 'dxf (vl-remove-if-not '(lambda (pair) (member (car pair)
      '(0 2 5 8 10 11 38 40 41 42 43 50 51 60 70 90 210 410))) data))))
(defun EL:LogFinish (status)
  ;; Date: 2026-10-21. A catch can return to the outer command after failure.
  ;; Keep that business result when its native wrapper subsequently returns.
  (if (and *EL:PerfActive* (not (equal status 'command-finished)))
    (setq *EL:PerfOutcome* status))
  (if *EL:LogActive*
    (progn
      (EL:LogEvent "END" status)
      (cond
        (*EL:DiagnosticsDeferred* nil)
        (*EL:PerfLogsOff* nil)
        (*EL:LogIOFailed* (princ "\n�����־д��ʧ�ܣ��뱣�������е�ʧ�ܽ׶κ������ġ�"))
        (*EL:LogWritten* (princ (strcat "\n�����־��" *EL:LogPath*)))
        (T (princ "\nδ������־�ļ����뱣����������Ϣ��")))))
  (setq *EL:LogActive* nil *EL:LogStack* nil)
  (if *EL:PerfLogOwner* (EL:PerfFinish status)))
(defun EL:CancelledMessage (message)
  ;; Date: 2026-10-21. EXIT/abort may be a validation failure, so only known
  ;; native user-cancel messages receive the cancelled outcome.
  (and (equal (type message) 'STR)
    (member (strcase (vl-string-trim " *\t\r\n" message))
      '("FUNCTION CANCELLED" "FUNCTION CANCELED" "CONSOLE BREAK" "USER BREAK" "������ȡ��"))))
(defun EL:LogFailure (message / laststate stack)
  (setq *EL:MonitorError* message)
  (setq laststate *EL:LogLast* stack *EL:LogStack*)
  (EL:LogEvent "ERROR" (list (cons 'message message) (cons 'stack stack) (cons 'last-event laststate)))
  (princ (strcat "\nԭʼ����" (EL:LogText message)
    "\nʧ�ܽ׶Σ�" (EL:LogText stack) "\n��������ģ�" (EL:LogText laststate)))
  (EL:LogFinish (if (EL:CancelledMessage message) 'cancelled 'failed)))

;; Date: 2026-10-09. Managed outputs never enter source recognition.
(defun EL:DiagramTag (entity / data)
  (if entity
    (progn (setq data (entget entity '("EL_FIXED_V1")))
      (cdr (assoc "EL_FIXED_V1" (cdr (assoc -3 data)))))))
(defun EL:ManagedEntity (entity) (if (EL:DiagramTag entity) T nil))

;; Date: 2026-10-11. Display numbers never replace persistent panel identity.
(defun EL:PanelNumber (data / value)
  (setq value (EL:Get 'panel-number data))
  (if (and (equal (type value) 'STR) (/= (vl-string-trim " \t\r\n" value) ""))
    value "���ޱ��"))

;; Date: 2026-10-11. Bounded evidence for exact snapshot differences, without parsing long strings.
(defun EL:StringDifference (before after / index start)
  (if (and (equal (type before) 'STR) (equal (type after) 'STR))
    (progn
      (setq index (cond ((vl-string-mismatch before after)) (T 0)) start (max 1 (- (1+ index) 100)))
      (list (cons 'offset index) (cons 'before-length (strlen before)) (cons 'after-length (strlen after))
        (cons 'before (substr before start 240)) (cons 'after (substr after start 240))))
    (list (cons 'before-type (type before)) (cons 'after-type (type after)))))
(defun EL:LogSnapshotDifference (before after / key a b keys typed)
  (setq typed (or
    (and (listp (EL:Get 'signature before)) (equal (car (EL:Get 'signature before)) 'EL_FIXED_SOURCE_V1))
    (and (listp (EL:Get 'signature after)) (equal (car (EL:Get 'signature after)) 'EL_FIXED_SOURCE_V1))))
  (setq keys (EL:Unique (append (mapcar 'car before) (mapcar 'car after))))
  (foreach key keys
    (setq a (EL:Get key before) b (EL:Get key after))
    (if (not (equal a b))
      (EL:LogEvent "SOURCE_FIELD_DIFFERENCE" (list (cons 'field key)
        (cons 'difference
          (if typed
            ;; Reuse bounded typed readback diagnostics; never reprint the failing snapshot.
            (EL:StoreDifference a b (list key))
            (EL:StringDifference
              (if (equal (type a) 'STR) a (EL:Signature a))
              (if (equal (type b) 'STR) b (EL:Signature b))))))))))

;; Date: 2026-10-13. Bounded business-stage timeline; no per-entity file I/O.
(defun EL:MonitorTitle (stage / name)
  (setq name (cdr (assoc stage
    '(("USER_INPUT" . "�ȴ�ʰȡ��������") ("PLACEMENT_INPUT" . "ԭ��ϵͳͼ���ã��� CAD �����������")
      ("UI_ACTION" . "������嶯��") ("LOAD_MODULE" . "����Դ��ģ��")
      ("LOAD_ROOT" . "ȷ��Ŀ¼���ͷ�������Դ") ("LOAD_LIBRARY" . "��ʼ��Ĭ���豸��")
      ("LOAD_ROOT_SEARCH" . "���Ҳ�ȷ�Ͻ���Ŀ¼") ("LOAD_RUNTIME" . "������������Ŀ¼")
      ("LOAD_RUNTIME_TEXT" . "�ͷŲ��ض�Դ�������") ("LOAD_RUNTIME_ASSETS" . "�ͷŲ��ض�Ĭ���豸��Դ")
      ("LOAD_BOOTSTRAP" . "����������ڼ���������")
      ("COLD_NATIVE_LOAD" . "����ֻ�� .NET ԭ�Ͳ�У������")
      ("COLD_NATIVE_PROBE" . "ִ��ֻ�� .NET ��ѡ�ɼ�������")
      ("PICK_PANEL" . "ʰȡ����䲢������·") ("PICK_TRUNK" . "ʰȡ���������߲�������·")
      ("PICK_STARTS" . "ʰȡ��·��ʼ�˵���") ("RECOGNIZE_STARTS" . "����ʼ����ʶ���·")
      ("PANEL_START_LOAD" . "��ȡ����ļ�") ("PANEL_START_NEW" . "�������")
      ("PANEL_START_INIT" . "��ʼ�����") ("PANEL_START_BUTTONS" . "����ʰȡ��ť")
      ("PANEL_START_WAIT" . "�������Ự") ("PANEL_DIALOG" . "��·�������Ự")
      ("PANEL_FILL" . "����·��ͼ��") ("PANEL_HISTORY_READ" . "���ر����¼")
      ("PANEL_HISTORY_RESTORE" . "�ָ������¼�еĻ�·��ͼ��")
      ("READ_STORE" . "��ȡ��ͼ��¼") ("STORE_READ" . "��ȡ��ͼ��¼")
      ("STORE_CURRENT_BOX" . "��ȡ��ǰ����䱣������")
      ("STORE_DECODE" . "�����¼") ("STORE_CACHE_CHECK" . "�˶Լ�¼����")
      ("NEW_RECORD" . "����������¼") ("PREPARE_PANEL" . "׼���������")
      ("RECOGNIZE_FIXED" . "ʶ��������·") ("RECOGNIZE_TRUNK" . "ʶ����������")
      ("RECOGNIZE_FIXED_RUN" . "ִ������ʶ��") ("SIMPLE_COLLECT" . "�ռ�ͼֽ��ѡ����")
      ("START_SNAPSHOT" . "������·��ʼ�˱߽�")
      ("START_BOUNDARY_FILTER" . "ɸѡ��ʼ�˱߽絼��")
      ("START_ENDS_BUILD" . "һ���Թ�����ʼ�˱߽�˵��")
      ("COLLECT_PRESET_PREPARE" . "�淶����Ԥ�����Ƽ�ͼ���")
      ("COLLECT_ENTITY_READ" . "��ȡ��ѡʵ��") ("COLLECT_CANDIDATES" . "���˺�ѡ����")
      ("COLLECT_SPATIAL_TREE" . "������ѡͼ��ռ���")
      ("COLLECT_CANDIDATE_DEDUP" . "��ѯ��ȥ�ز���ȡ���߼��Ͽں�ѡ")
      ("COLLECT_DEVICE_EXPAND" . "��չ�����豸��ѡ��")
      ("ROOT_SCOPE_DISCOVERY" . "����㷢�־�ϸ��������")
      ("ROOT_SCOPE_PANEL_SHAPE" . "׼������������������")
      ("ROOT_SCOPE_BLOCK_RECORDS" . "�����������ֺ�ѡͼ�鼰��ɫ")
      ("ROOT_SCOPE_ROOT_PREPARE" . "׼����㼰�߽羫������")
      ("ROOT_SCOPE_START_SNAPSHOT" . "��������������ʼ�˿���")
      ("ROOT_SCOPE_WIRE_INDEX" . "�����������ֵ�������")
      ("ROOT_SCOPE_BLOCK_INDEX" . "������������ͼ������")
      ("ROOT_SCOPE_JUNCTION_INDEX" . "�����������ֽ��ߺ�����")
      ("ROOT_SCOPE_END_INDEX" . "�����������ֶ˵�����")
      ("ROOT_SCOPE_GAP_SNAPSHOT" . "׼���������ֶϿڿ���")
      ("ROOT_SCOPE_ROOT_LINKS" . "�����������ֶ˵��¼���������")
      ("ROOT_SCOPE_REACHABLE_TRACE" . "׷��������������辫��")
      ("ROOT_SCOPE_RESULT_ORDER" . "��Դ˳��������ϸ�������")
      ("ROOT_SCOPE_CANDIDATE_ORDER" . "��ԭ��ϸ��ѡͼ��ԭ˳��")
      ("PANEL_SELECT_EXITS" . "��������·����") ("PANEL_COMPUTE" . "������幦�ʼ�״̬")
      ("PANEL_PREVIEW_PALETTE" . "׼�����ͷ�ɫԤ��������ɫ")
      ("PREVIEW_SOURCE_COLORS" . "��ȡ��ȥ��ԭ������ɫ") ("PREVIEW_PALETTE_FILTER" . "ɸѡ�ܿ�ԭ���ߵ�Ԥ����ɫ")
      ("SIMPLE_NETWORK" . "׼����������") ("NETWORK_BUILD" . "������������")
      ("NETWORK_PROOF_PREPARE" . "�������縴��֤��")
      ("NETWORK_PROOF_STABLE_INPUT" . "�淶�����������") ("NETWORK_PROOF_STABLE_OUTPUT" . "�淶�����������")
      ("NETWORK_PROOF_CONTACTS" . "��������Ӵ�֤��") ("NETWORK_ROLE_RESTORE" . "��ԭ���������ɫ")
      ("NETWORK_PROOF_COMPARE" . "�����˶���������֤��")
      ("COMPONENT_INDEX" . "������ͨ��ϵ����")
      ("NETWORK_WIRE_CONTACT" . "��鵼�߽Ӵ�") ("NETWORK_CANDIDATE_SCOPE" . "׼�������ɫ�Ϳռ�����")
      ("NETWORK_ROLE_PREPARE" . "׼������ͼ���ɫ����¼")
      ("NETWORK_WIRE_INDEX" . "�������߽Ӵ���������¼")
      ("NETWORK_BLOCK_INDEX" . "����ͼ��Ӵ�����")
      ("NETWORK_JUNCTION_INDEX" . "�������ߺ�����")
      ("NETWORK_END_INDEX" . "�������߶˵�����")
      ("NETWORK_GAP_INDEX" . "�����Ͽ��ϰ�����")
      ("NETWORK_ROOT_LINKS" . "�����˵��¼����ʼ����")
      ("NETWORK_DEVICE_CONTACT" . "����豸�Ӵ�") ("NETWORK_GAPS" . "����������")
      ("NETWORK_REACHABLE_TRACE" . "����ʼ����������ʵ����")
      ("NETWORK_CONTACT_NODES" . "�ϲ�ͬһ�ӵ���ظ�����")
      ("NETWORK_SIGNATURE" . "����ȥ�غ�ļ���֤��") ("NETWORK_VERIFY_GEOMETRY" . "�˶����缸��")
      ("SOURCE_NATIVE_VERIFY" . "�˶�Դͼԭ�������뷶Χ")
      ("SPLIT_NETWORK" . "��ֻ�·") ("CIRCUIT_NUMBER_SCOPE" . "ʶ���·��ŷ�Χ")
      ("NUMBER_ANNOTATION_INDEX" . "��ȡ����ƽ���Ź�������")
      ("COMPARE_SOURCE_NUMBER" . "�˶Ի�·���") ("PRE_GENERATE_FRESH" . "����ǰ�˶�Դͼ")
      ("FRESH_SOURCE_SCAN" . "�˶Ե�ǰԴͼ") ("CCKK2" . "�����������ϵͳͼ")
      ("CCKK2_CREATE" . "���������ϵͳͼ") ("SAVE_CREATED_DIAGRAM" . "�������ɵ�ϵͳͼ��¼")
      ("TX_WRITE" . "д��ϵͳͼ�������¼") ("STORE_SERIALIZE" . "���л������¼")
      ("STORE_PARSE" . "�������˶����л�����") ("STORE_REPLACE_PAYLOAD" . "д��ͼֽ��¼�غ�")
      ("STORE_MIGRATE_BACKUP" . "���ݾɰ�������¼") ("STORE_STAGE_BUILD" . "�������մ������¼")
      ("STORE_COMPACT" . "����������¼����") ("STORE_PACK_INTS" . "ѹ����������")
      ("STORE_NATIVE_ENCODE" . "����ͼֽԭ���ֶ�") ("STORE_NATIVE_DECODE" . "����ͼֽԭ���ֶ�")
      ("STORE_EXPAND" . "��ԭ������¼����")
      ("STORE_UNPACK_INTS" . "չ����������") ("STORE_VALUE_DECODE" . "��ԭ��¼�ֶνṹ")
      ("STORE_READBACK" . "�ض��˶Ա�������") ("STORE_CONTEXT_COMMIT" . "�˶��ύ���������")
      ("STORE_CONTEXT_READ" . "��ȡ�ύ���������") ("SAVE_GENERATION_DRAFT" . "�������ɲݸ�")
      ("UNDO_BEGIN" . "��ʼ������") ("UNDO_END" . "����������")
      ("TX_MARKER_CREATE" . "����������") ("DIAGRAM_VIEW" . "��λ����ϵͳͼ")
      ("DEVICE_LIBRARY_LOAD" . "��ȡ�豸��") ("DEVICE_LEGEND" . "�����豸ͼ��")
      ("SYSTEM_LIBRARY_OPEN" . "��ϵͳͼ���") ("SYSTEM_BLOCK_COPY" . "����ȱ��ϵͳͼ��")
      ("SYSTEM_STYLE_COPY" . "����ȱ��������ʽ") ("TEMPLATE_CAPTURE" . "׼��ϵͳͼģ��")
      ("TEMPLATE_VALIDATE" . "��������ϵͳͼģ��")
      ("PANEL_SUBMIT_PREPARE" . "����ύ���ͬ��׼��")
      ("GENERATION_CONTEXT" . "��ȡ��׼������������") ("GENERATION_PREPARE" . "�������ɻ�·����")
      ("GENERATION_SOURCE_VERIFY" . "����ǰԴͼ�ͱ�ź˶�")
      ("GENERATION_PLAN" . "����ϵͳͼ�����ƻ�") ("GENERATION_RECORD" . "׼���������ɼ�¼")
      ("PLACEMENT_PLAN_REBUILD" . "��ԭ��ʵ��λ���ؽ��ƻ�")
      ("NATIVE_INSERT" . "�̶�λ��ԭ������")
      ("PANEL_DYNAMIC_SET" . "�л����嶯̬״̬") ("CIRCUIT_DYNAMIC_SET" . "�л���·��̬״̬")
      ("PLACEMENT_TEMPLATE_VERIFY" . "���ú󸴺�ģ��") ("PLACEMENT_NUMBER_VERIFY" . "���ú�˶Ա��")
      ("PLACEMENT_LIBRARY_VERIFY" . "���ú�˶��豸��") ("PLACEMENT_SOURCE_VERIFY" . "���ú�˶�Դͼ")
      ("CREATE_CIRCUITS" . "����ȫ����·����������") ("CREATE_POWER_TEXT" . "����ʵ�ʻ�·��������")
      ("CREATE_CAPTIONS" . "������š���ź���;����")
      ("DIAGRAM_FINALIZE" . "ͼ����ɺ�ļ�¼����")
      ("TX_MARKER_CLEANUP" . "����������") ("TX_COMMIT" . "�ύ�����������������")
      ("DIAGNOSTIC_EXPORT" . "�����������")))))
  (if name name stage))
(defun EL:MonitorActionTile (key code)
  ;; Keep original callback expressions in the same DCL scope, including $value.
  (action_tile key (strcat "(EL:MonitorUIBegin $key $value) " code " (EL:MonitorUIEnd)")))
(defun EL:MonitorUIBegin (key value / *EL:MonitorLabel* title)
  ;; Date: 2026-10-21. No proof survives a user action or unknown callback.
  (EL:FreshBoundary)
  (setq title (cdr (assoc key
    '(("p_pick" . "ʰȡ�����") ("p_trunk" . "ʰȡ��·��ʼ�˵���")
      ("accept" . "�����ȷ��")
      ("p_block_library_open" . "��ϵͳͼ���ļ���")
      ("p_system_drawing" . "��鱾ͼϵͳͼ��") ("p_system_import" . "��ͼ�ⲹ��ϵͳͼȱ��")
      ("cancel" . "ȡ�����˳�") ("p_generate" . "������ϵͳͼ") ("p_diagnostic" . "���������־")
      ("f_preview" . "�鿴ȫ����·")
      ("p_capacity" . "�޸����������")
      ("dl_rows" . "ѡ���豸����Ŀ") ("dl_query" . "�����豸��")
      ("dl_new" . "�����豸") ("dl_pick" . "ʰȡ�豸���")
      ("dl_open" . "���豸������ļ�����λ��")
      ("dl_save" . "�����豸���˶Խ��")
      ("dl_import" . "�����豸��") ("dl_export" . "�����豸��")
      ("dl_watts" . "�޸��豸���ʲ��Զ�����") ("dl_delete" . "ɾ���豸")
      ("dl_restore" . "�ָ��豸") ("dl_refresh" . "ˢ���豸��")
      ("dl_close" . "�ر��豸��")))))
  (if (not title) (setq title "�޸Ŀؼ���ִ�а�ť"))
  (setq *EL:MonitorLabel* (strcat title " [" key "]=" (if value (substr value 1 160) ""))
    *EL:MonitorUIStack* (cons (EL:PerfBegin "UI_ACTION") *EL:MonitorUIStack*)))
(defun EL:MonitorUIEnd ()
  (EL:PerfEnd (car *EL:MonitorUIStack*) 'returned)
  (setq *EL:MonitorUIStack* (cdr *EL:MonitorUIStack*))
  (EL:FreshBoundary))
(defun EL:MonitorSeconds (milliseconds / fraction)
  ;; DIMZIN must not strip the leading/trailing zeroes in timing columns.
  (setq fraction (strcat "00" (itoa (fix (rem milliseconds 1000)))))
  (strcat (rtos (fix (/ milliseconds 1000.0)) 2 0) "." (substr fraction (- (strlen fraction) 2))))
(defun EL:MonitorCell (value / text)
  (setq text (cond ((equal (type value) 'STR) value) (value (vl-prin1-to-string value)) (T "-")))
  (vl-string-translate "|\r\n" "/  " text))
(defun EL:MonitorTable (file rows origin / row start duration)
  (EL:MonitorLine "|���|������|��ʼ��|������|��ʱ��|������|������|��������|�׶�|���|" file)
  (EL:MonitorLine "|---:|---:|---:|---:|---:|---:|---:|---|---|---|" file)
  (foreach row (vl-sort rows '(lambda (a b) (< (EL:Get 'id a) (EL:Get 'id b))))
    (setq start (EL:PerfDelta origin (EL:Get 'start row)) duration (EL:Get 'elapsed-ms row))
    (EL:MonitorLine (strcat "|" (itoa (EL:Get 'id row)) "|" (itoa (EL:Get 'parent-id row))
      "|" (EL:MonitorSeconds start) "|" (EL:MonitorSeconds (+ start duration))
      "|" (EL:MonitorSeconds duration) "|" (EL:MonitorSeconds (EL:Get 'program-ms row))
      "|" (EL:MonitorSeconds (- duration (EL:Get 'program-ms row)))
      "|" (EL:MonitorTitle (EL:Get 'stage row)) " " (EL:MonitorCell (EL:Get 'label row))
      "|" (EL:Get 'stage row) "|" (if (equal (EL:Get 'status row) 'returned) "�ѷ���" "�ж�") "|") file)))
(defun EL:MonitorWriteBody (file summary / stamp row)
  (setq stamp *EL:MonitorStamp*)
  (EL:MonitorLine "# Ӧ������ȫ���̶�����ʱ" file)
  (EL:MonitorLine (strcat "���ڣ�" (substr stamp 1 4) "-" (substr stamp 5 2) "-" (substr stamp 7 2)) file)
  (EL:MonitorLine (strcat "ԭ������״̬��" (EL:MonitorCell (EL:Get 'status summary))
    "������ҵ������" (EL:MonitorCell (EL:Get 'last-outcome summary))) file)
  (EL:MonitorLine (strcat "����ʱ�� CDATE��" stamp "�����" (EL:Get 'command summary)
    "�������汾��" (EL:MonitorCell (EL:Get 'package summary))) file)
  (if (assoc "recognition-compare-mode" (EL:Get 'metrics summary))
    (EL:MonitorLine (strcat "ʶ�����ģʽ��"
      (itoa (EL:Get "recognition-compare-mode" (EL:Get 'metrics summary))) "��"
      (EL:PerformanceCompareLabel (EL:Get "recognition-compare-mode" (EL:Get 'metrics summary)))) file))
  (EL:MonitorLine "" file)
  (EL:MonitorLine "��λΪ�룬������λС���������������Ӷ��������ɽ�������ӡ�������������ȴ����䣬�ѿ۳���������ص�������ԭ�������ð��� CAD ����������δ�������Ĺ��������ڸ���������ʱ���С�" file)
  (EL:MonitorLine "��¼�û�������ҵ��׶Σ����ߡ�ʵ�塢�����ѭ�������μ�ʱ���������д�ļ�����ʼ�������뺯�����ѷ���ֻ��ʾ�������أ�ҵ��ɹ������ҵ����Ϊ׼��" file)
  (if (and *EL:MonitorLoadSummary* (not (equal (EL:Get 'command summary) "APPLOAD")))
    (progn
      (EL:MonitorLine "" file) (EL:MonitorLine "## ���һ�β������" file)
      (EL:MonitorLine (strcat "����ʱ�� CDATE��" *EL:MonitorLoadStamp* "�����غ�ʱ��"
        (EL:MonitorSeconds (EL:Get 'total-ms *EL:MonitorLoadSummary*)) " �롣���ؽ�������������Ŀ��м������������ʱ��") file)
      (EL:MonitorTable file *EL:MonitorLoadRows* *EL:MonitorLoadOrigin*)))
  (EL:MonitorLine "" file) (EL:MonitorLine "## ����ִ�����˳�" file)
  (EL:MonitorLine (strcat "�ܺ�ʱ " (EL:MonitorSeconds (EL:Get 'total-ms summary))
    " �룻���� " (EL:MonitorSeconds (EL:Get 'program-ms summary)) " �룻���� "
    (EL:MonitorSeconds (EL:Get 'interaction-ms summary)) " �롣") file)
  (if (EL:Get 'after-graphics summary)
    (EL:MonitorLine (strcat "ȫ��ͼ���������ɺ����β��"
      (EL:MonitorSeconds (EL:Get 'inclusive-ms (EL:Get 'after-graphics summary))) " �롣") file))
  (if *EL:MonitorError* (EL:MonitorLine (strcat "�����ȡ��ԭ��" (EL:MonitorCell *EL:MonitorError*)) file))
  (EL:MonitorLine "���� 0�����ʼ�����ʱ�� 0.000 �롣" file)
  (EL:MonitorTable file *EL:MonitorRows* *EL:PerfStarted*)
  (EL:MonitorLine (strcat "�˳���" (EL:MonitorSeconds (EL:Get 'total-ms summary)) " �롣") file)
  (EL:MonitorLine "" file) (EL:MonitorLine "## ������������" file)
  (foreach row (EL:Get 'metrics summary)
    (EL:MonitorLine (strcat "- " (car row) "��" (EL:MonitorCell (cdr row))) file))
  (if *EL:DiagnosticLogEvents*
    (progn
      (EL:MonitorLine "" file) (EL:MonitorLine "## ����¼�" file)
      (foreach row (reverse *EL:DiagnosticLogEvents*)
        (EL:MonitorLine (strcat (itoa (car row)) " | " (cadr row) " | "
          (EL:MonitorCell (EL:LogText (caddr row)))) file)))))
(defun EL:MonitorLine (text ignored)
  (setq *EL:MonitorLines* (cons (strcat text "\r\n") *EL:MonitorLines*)))
(defun EL:MonitorJoin (parts / joined)
  (while (cdr parts)
    (setq joined nil)
    (while parts
      (setq joined (cons (if (cdr parts) (strcat (car parts) (cadr parts)) (car parts)) joined)
        parts (cddr parts)))
    (setq parts (reverse joined)))
  (if parts (car parts) ""))
(defun EL:MonitorStreamWrite (stream path text)
  ;; Explicit UTF-8 even with LISPSYS=0 and GB2312-loaded source.
  (vlax-put-property stream 'Type 2)
  (vlax-put-property stream 'Charset "utf-8")
  (vlax-invoke-method stream 'Open nil 0 -1 "" "")
  (vlax-invoke-method stream 'WriteText text 0)
  (vlax-invoke-method stream 'SaveToFile path 1) T)
(defun EL:MonitorWrite (path summary / stream result closed tmp started *EL:MonitorLines*)
  (setq started (EL:Tick) tmp (strcat path ".tmp"))
  (EL:MonitorWriteBody nil summary)
  (EL:MonitorLine "�������λ��ҵ���ʱ֮�⣻monitor-export-ms ������д�����رպ��ļ�������" nil)
  (setq result (vl-catch-all-apply '(lambda ()
    (setq stream (vlax-create-object "ADODB.Stream"))
    (EL:MonitorStreamWrite stream tmp (EL:MonitorJoin (reverse *EL:MonitorLines*)))) nil))
  (if stream
    (progn
      (setq closed (vl-catch-all-apply 'vlax-invoke-method (list stream 'Close)))
      (vlax-release-object stream)))
  (if (and (not (vl-catch-all-error-p result)) result
      (not (vl-catch-all-error-p closed)))
    (setq result (vl-catch-all-apply 'vl-file-rename (list tmp path)))
    (setq result nil))
  (if (or (not result) (vl-catch-all-error-p result))
    (progn (vl-catch-all-apply 'vl-file-delete (list tmp)) (setq result nil)))
  (setq *EL:MonitorExportMS* (EL:PerfDelta started (EL:Tick))) result)
(defun EL:MonitorReport (summary / folder path result suffix)
  ;; One write per completed command; retain memory on I/O failure.
  (setq *EL:MonitorLastRows* *EL:MonitorRows*)
  (if (equal (EL:Get 'command summary) "APPLOAD")
    (setq *EL:MonitorLoadRows* *EL:MonitorRows* *EL:MonitorLoadSummary* summary
      *EL:MonitorLoadOrigin* *EL:PerfStarted* *EL:MonitorLoadStamp* *EL:MonitorStamp*))
  (setq result (vl-catch-all-apply 'EL:MonitorSave (list summary nil)))
  (if (or (vl-catch-all-error-p result) (not result))
    (setq result (vl-catch-all-apply 'EL:MonitorSave (list summary T))))
  (if (and result (not (vl-catch-all-error-p result)))
    (progn (setq *EL:PerfLastSummary* (EL:Put 'monitor-export-ms *EL:MonitorExportMS* *EL:PerfLastSummary*))
      (princ (strcat "\nȫ���̺�ʱ�ĵ���" *EL:MonitorPath* "�������ʱ " (EL:MonitorSeconds *EL:MonitorExportMS*) " �롣")))
    (princ "\nȫ�����ĵ�д��ʧ�ܣ����������� *EL:MonitorLastRows*�����ܱ����� *EL:PerfLastSummary*��")) nil)
(defun EL:MonitorSave (summary fallback / folder path suffix base)
  (setq folder (if (or fallback (not *EL:Root*)) (getvar "TEMPPREFIX") (strcat *EL:Root* "output/")))
  (vl-mkdir folder)
  (setq base (strcat folder "ELMONITOR-" *EL:MonitorStamp* "-" (EL:Get 'command summary)) suffix 0
    path (strcat base ".md"))
  (while (findfile path)
    (setq suffix (1+ suffix) path (strcat base "-" (itoa suffix) ".md")))
  (if (EL:MonitorWrite path summary) (setq *EL:MonitorPath* path)))
(defun EL:ExportDiagnosticRun (/ run path
    *EL:MonitorRows* *EL:PerfStarted* *EL:MonitorStamp* *EL:MonitorError* *EL:DiagnosticLogEvents*
    *EL:MonitorLoadSummary* *EL:MonitorLoadRows* *EL:MonitorLoadOrigin* *EL:MonitorLoadStamp*)
  ;; Date: 2026-10-15. Restore the completed run locally; exporting while a
  ;; new panel is open must neither replace nor finish that panel's timer.
  (if (setq run (EL:Get (namedobjdict) *EL:DiagnosticRuns*))
    (progn
      (setq *EL:MonitorRows* (EL:Get 'rows run) *EL:PerfStarted* (EL:Get 'origin run)
        *EL:MonitorStamp* (EL:Get 'stamp run) *EL:MonitorError* (EL:Get 'error run)
        *EL:DiagnosticLogEvents* (EL:Get 'events run)
        *EL:MonitorLoadSummary* (EL:Get 'load-summary run) *EL:MonitorLoadRows* (EL:Get 'load-rows run)
        *EL:MonitorLoadOrigin* (EL:Get 'load-origin run) *EL:MonitorLoadStamp* (EL:Get 'load-stamp run))
      (setq path (EL:MeasuredCatch 'EL:MonitorSave (list (EL:Get 'summary run) nil)))
      (if (or (vl-catch-all-error-p path) (not path))
        (setq path (EL:MeasuredCatch 'EL:MonitorSave (list (EL:Get 'summary run) T))))
      (EL:Require (and (not (vl-catch-all-error-p path)) path)
        "ȫ���������־����ʧ�ܣ��ڴ��¼�ѱ������������Ŀ¼Ȩ�ޡ�")
      (if path (princ (strcat "\nȫ���������־�ѵ�����" (vl-string-translate "/" "\\" path)))) path)))
(defun EL:MonitorLoadBegin (started / token)
  ;; Date: 2026-10-13. Finish the old clock before a reload changes its origin.
  ;; A cancelled command must never become the parent of later APPLOAD events.
  (if *EL:PerfActive*
    (progn
      (setq *EL:MonitorError* "RELOADED: �ϴ�ִ�б����¼����ж�")
      (EL:LogFinish 'interrupted-by-load)
      (EL:PerfFinish 'interrupted-by-load)))
  (EL:PerfStart "APPLOAD")
  (setq *EL:PerfStarted* started token (EL:PerfBegin "LOAD_BOOTSTRAP"))
  (setq *EL:PerfPending* (vl-remove token *EL:PerfPending*) token (EL:Put 'start started token)
    *EL:PerfPending* (cons token *EL:PerfPending*))
  (EL:PerfEnd token 'returned)
  (setq *EL:MonitorOldError* *error*)
  (defun *error* (message)
    (setq *EL:MonitorError* message *error* *EL:MonitorOldError*)
    (EL:PerfFinish 'load-failed)
    (princ (strcat "\n�������ʧ�ܣ�" message)) (princ)))
(defun EL:MonitorLoadEnd (status)
  (setq *error* *EL:MonitorOldError*)
  (EL:PerfFinish status))
